'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');

    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });

    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.error || 'خطا در ثبت‌نام');
      return;
    }

    setMessage('ثبت‌نام با موفقیت انجام شد. حالا وارد شوید.');
    setForm({ name: '', email: '', password: '' });
  }

  return (
    <div className="auth-page">
      <div className="card auth-card">
        <div className="badge">سهامداران متانت</div>
        <h1>ایجاد حساب</h1>
        <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 12 }}>
          <input className="input" placeholder="نام نمایشی" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="input" placeholder="ایمیل" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input className="input" placeholder="رمز عبور" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          {error ? <div style={{ color: '#fca5a5', fontSize: 14 }}>{error}</div> : null}
          {message ? <div style={{ color: '#86efac', fontSize: 14 }}>{message}</div> : null}
          <button className="btn btn-primary" disabled={loading}>{loading ? 'در حال ثبت‌نام...' : 'ثبت‌نام'}</button>
        </form>
        <p style={{ marginTop: 18, color: 'var(--muted)' }}>
          حساب دارید؟ <Link href="/login" style={{ color: '#7dd3fc' }}>ورود</Link>
        </p>
      </div>
    </div>
  );
}
