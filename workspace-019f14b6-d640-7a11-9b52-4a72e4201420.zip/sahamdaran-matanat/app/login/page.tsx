'use client';

import { signIn } from 'next-auth/react';
import Link from 'next/link';
import { useState } from 'react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const result = await signIn('credentials', { email, password, redirect: false, callbackUrl: '/chat' });
    setLoading(false);

    if (result?.error) {
      setError('ایمیل یا رمز عبور نادرست است.');
      return;
    }

    window.location.href = '/chat';
  }

  return (
    <div className="auth-page">
      <div className="card auth-card">
        <div className="badge">پیام‌رسان سهامداران متانت</div>
        <h1>ورود به حساب</h1>
        <p style={{ color: 'var(--muted)' }}>با ایمیل و رمز عبور وارد شوید.</p>
        <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 12 }}>
          <input className="input" placeholder="ایمیل" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input" placeholder="رمز عبور" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {error ? <div style={{ color: '#fca5a5', fontSize: 14 }}>{error}</div> : null}
          <button className="btn btn-primary" disabled={loading}>{loading ? 'در حال ورود...' : 'ورود'}</button>
        </form>
        <p style={{ marginTop: 18, color: 'var(--muted)' }}>
          حساب ندارید؟ <Link href="/register" style={{ color: '#7dd3fc' }}>ثبت‌نام</Link>
        </p>
      </div>
    </div>
  );
}
