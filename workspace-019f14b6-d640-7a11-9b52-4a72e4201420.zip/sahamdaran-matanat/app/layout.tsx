import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'سهامداران متانت',
  description: 'پیام‌رسان سهامداران متانت'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
