import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { getConversationById, getConversations } from '@/lib/data';
import { SidebarRealtime } from '@/components/SidebarRealtime';
import { ChatRoomClient } from '@/components/ChatRoomClient';

export default async function ChatRoomPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) redirect('/login');

  const [conversations, conversation] = await Promise.all([
    getConversations(session.user.id),
    getConversationById(params.id, session.user.id)
  ]);

  if (!conversation) redirect('/chat');

  return (
    <div className="layout-shell">
      <SidebarRealtime initialConversations={conversations} currentId={conversation.id} sessionUserId={session.user.id} />
      <main className="main-panel">
        <ChatRoomClient
          sessionUserId={session.user.id}
          sessionUserName={session.user.name || 'کاربر'}
          conversation={JSON.parse(JSON.stringify(conversation))}
        />
      </main>
    </div>
  );
}
