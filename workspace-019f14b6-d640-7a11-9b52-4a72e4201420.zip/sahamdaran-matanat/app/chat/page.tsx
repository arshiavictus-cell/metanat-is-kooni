import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { authOptions } from '@/lib/auth';
import { getConversations } from '@/lib/data';
import { SidebarRealtime } from '@/components/SidebarRealtime';

export default async function ChatIndexPage() {
  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) redirect('/login');

  const conversations = await getConversations(session.user.id);

  return (
    <div className="layout-shell">
      <SidebarRealtime initialConversations={conversations} sessionUserId={session.user.id} />
      <main className="main-panel" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
        <div className="card" style={{ width: 'min(720px, 100%)', padding: 32, textAlign: 'center' }}>
          <div className="badge">سهامداران متانت</div>
          <h1>به پیام‌رسان خوش آمدید</h1>
          <p style={{ color: 'var(--muted)', lineHeight: 2 }}>
            از ستون کناری یک گفت‌وگو را انتخاب کنید یا یک چت جدید بسازید.
          </p>
          <Link href="/new-chat" className="btn btn-primary">شروع گفت‌وگوی جدید</Link>
        </div>
      </main>
    </div>
  );
}
