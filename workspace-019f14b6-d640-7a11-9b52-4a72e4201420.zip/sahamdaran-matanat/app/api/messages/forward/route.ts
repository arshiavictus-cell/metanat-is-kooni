import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const formData = await req.formData();
  const messageId = String(formData.get('messageId') || '');
  const conversationId = String(formData.get('conversationId') || '');

  const original = await prisma.message.findUnique({ where: { id: messageId } });
  if (!original) return NextResponse.json({ error: 'پیام پیدا نشد.' }, { status: 404 });

  const member = await prisma.conversationMember.findFirst({ where: { conversationId, userId: session.user.id } });
  if (!member) return NextResponse.json({ error: 'دسترسی ندارید.' }, { status: 403 });

  const forwarded = await prisma.message.create({
    data: {
      conversationId,
      senderId: session.user.id,
      content: original.content,
      type: original.type,
      attachmentUrl: original.attachmentUrl,
      attachmentName: original.attachmentName,
      attachmentMime: original.attachmentMime,
      forwardedFromId: original.id
    }
  });

  await prisma.conversation.update({
    where: { id: conversationId },
    data: { updatedAt: new Date() }
  });

  return NextResponse.redirect(new URL(`/chat/${conversationId}`, req.url));
}
