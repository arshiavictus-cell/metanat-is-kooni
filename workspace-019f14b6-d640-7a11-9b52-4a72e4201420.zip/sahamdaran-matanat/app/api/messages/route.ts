import { NextResponse } from 'next/server';

export async function POST() {
  return NextResponse.json({
    ok: true,
    message: 'ارسال پیام از طریق Socket.IO انجام می‌شود.'
  });
}
