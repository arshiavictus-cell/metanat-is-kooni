import { NextResponse } from 'next/server';

export async function POST() {
  const response = NextResponse.redirect(new URL('/login', process.env.NEXTAUTH_URL || 'http://localhost:3000'));
  response.cookies.set('next-auth.session-token', '', { expires: new Date(0), path: '/' });
  response.cookies.set('__Secure-next-auth.session-token', '', { expires: new Date(0), path: '/' });
  return response;
}
