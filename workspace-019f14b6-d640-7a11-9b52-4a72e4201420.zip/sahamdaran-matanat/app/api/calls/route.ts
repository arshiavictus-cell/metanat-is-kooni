import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const formData = await req.formData();
  const conversationId = String(formData.get('conversationId') || '');
  const type = String(formData.get('type') || 'AUDIO') as 'AUDIO' | 'VIDEO';

  const member = await prisma.conversationMember.findFirst({ where: { conversationId, userId: session.user.id } });
  if (!member) return NextResponse.json({ error: 'دسترسی ندارید.' }, { status: 403 });

  await prisma.call.create({
    data: {
      conversationId,
      initiatedById: session.user.id,
      type,
      status: 'ENDED',
      endedAt: new Date()
    }
  });

  await prisma.message.create({
    data: {
      conversationId,
      senderId: session.user.id,
      type: 'SYSTEM',
      content: type === 'VIDEO' ? 'یک تماس تصویری ثبت شد.' : 'یک تماس صوتی ثبت شد.'
    }
  });

  await prisma.conversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } });
  return NextResponse.redirect(new URL(`/chat/${conversationId}`, req.url));
}
