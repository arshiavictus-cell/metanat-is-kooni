import { NextResponse } from 'next/server';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';
import { cloudinary } from '@/lib/cloudinary';

function detectType(mime = '') {
  if (mime.startsWith('image/')) return 'IMAGE';
  if (mime.startsWith('audio/')) return 'AUDIO';
  if (mime) return 'FILE';
  return 'TEXT';
}

async function uploadToCloudinary(file: File) {
  const bytes = Buffer.from(await file.arrayBuffer());
  const dataUri = `data:${file.type};base64,${bytes.toString('base64')}`;
  const result = await cloudinary.uploader.upload(dataUri, {
    folder: 'sahamdaran-matanat',
    resource_type: 'auto'
  });

  return {
    url: result.secure_url,
    name: file.name,
    mime: file.type,
    type: detectType(file.type)
  };
}

async function uploadLocalFallback(file: File) {
  const bytes = Buffer.from(await file.arrayBuffer());
  const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
  await mkdir(uploadsDir, { recursive: true });
  const safeName = `${Date.now()}-${file.name.replace(/\s+/g, '-')}`;
  await writeFile(path.join(uploadsDir, safeName), bytes);

  return {
    url: `/uploads/${safeName}`,
    name: file.name,
    mime: file.type,
    type: detectType(file.type)
  };
}

export async function POST(req: Request) {
  const formData = await req.formData();
  const file = formData.get('file') as File | null;

  if (!file || file.size === 0) {
    return NextResponse.json({ error: 'فایلی ارسال نشده است.' }, { status: 400 });
  }

  const hasCloudinary = !!process.env.CLOUDINARY_CLOUD_NAME && !!process.env.CLOUDINARY_API_KEY && !!process.env.CLOUDINARY_API_SECRET;
  const uploaded = hasCloudinary ? await uploadToCloudinary(file) : await uploadLocalFallback(file);
  return NextResponse.json({ ok: true, ...uploaded, storage: hasCloudinary ? 'cloudinary' : 'local' });
}
