import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { getConversations } from '@/lib/data';
import { Sidebar } from '@/components/Sidebar';

async function createConversation(formData: FormData) {
  'use server';

  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) redirect('/login');

  const mode = String(formData.get('mode') || 'DIRECT');
  const email = String(formData.get('email') || '');
  const title = String(formData.get('title') || '');
  const members = String(formData.get('members') || '');

  if (mode === 'DIRECT') {
    const target = await prisma.user.findUnique({ where: { email } });
    if (!target) redirect('/new-chat?error=user-not-found');

    const conversation = await prisma.conversation.create({
      data: {
        type: 'DIRECT',
        members: {
          create: [
            { userId: session.user.id },
            { userId: target.id }
          ]
        }
      }
    });

    redirect(`/chat/${conversation.id}`);
  }

  const emails = members.split(',').map((item) => item.trim()).filter(Boolean);
  const users = await prisma.user.findMany({ where: { email: { in: emails } } });
  const memberCreates = users.map((user) => ({ userId: user.id }));

  const conversation = await prisma.conversation.create({
    data: {
      type: 'GROUP',
      title: title || 'گروه جدید',
      members: {
        create: [
          { userId: session.user.id, role: 'owner' },
          ...memberCreates
        ]
      }
    }
  });

  redirect(`/chat/${conversation.id}`);
}

export default async function NewChatPage({ searchParams }: { searchParams: { error?: string } }) {
  const session = await getServerSession(authOptions as any);
  if (!session?.user?.id) redirect('/login');

  const conversations = await getConversations(session.user.id);

  return (
    <div className="layout-shell">
      <Sidebar conversations={conversations} />
      <main className="main-panel" style={{ padding: 24 }}>
        <div className="card" style={{ maxWidth: 760, margin: '0 auto', padding: 24 }}>
          <div className="badge">ایجاد گفتگو</div>
          <h1>چت جدید</h1>
          {searchParams.error === 'user-not-found' ? <div style={{ color: '#fca5a5' }}>کاربری با این ایمیل پیدا نشد.</div> : null}

          <form action={createConversation} style={{ display: 'grid', gap: 14, marginTop: 20 }}>
            <label>
              <div style={{ marginBottom: 8 }}>نوع گفتگو</div>
              <select className="input" name="mode" defaultValue="DIRECT">
                <option value="DIRECT">چت خصوصی</option>
                <option value="GROUP">گروه</option>
              </select>
            </label>

            <label>
              <div style={{ marginBottom: 8 }}>ایمیل کاربر برای چت خصوصی</div>
              <input className="input" name="email" placeholder="example@mail.com" />
            </label>

            <label>
              <div style={{ marginBottom: 8 }}>نام گروه</div>
              <input className="input" name="title" placeholder="مثلاً سهامداران ویژه" />
            </label>

            <label>
              <div style={{ marginBottom: 8 }}>اعضای گروه با ایمیل، جداشده با ویرگول</div>
              <textarea className="textarea" name="members" rows={4} placeholder="ali@mail.com, sara@mail.com" />
            </label>

            <button className="btn btn-primary">ایجاد گفتگو</button>
          </form>
        </div>
      </main>
    </div>
  );
}
