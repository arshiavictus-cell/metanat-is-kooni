type SocketUser = {
  userId: string;
  conversationIds: string[];
};

declare global {
  var socketUsers: Map<string, SocketUser> | undefined;
}

export const socketUsers = global.socketUsers || new Map<string, SocketUser>();
if (!global.socketUsers) global.socketUsers = socketUsers;
