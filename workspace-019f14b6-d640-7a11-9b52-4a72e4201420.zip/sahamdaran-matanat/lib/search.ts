import { prisma } from '@/lib/prisma';

export async function searchMessages(userId: string, q: string) {
  if (!q.trim()) return [];

  const messages = await prisma.message.findMany({
    where: {
      deletedAt: null,
      content: { contains: q, mode: 'insensitive' },
      conversation: {
        members: {
          some: { userId }
        }
      }
    },
    include: {
      sender: true,
      conversation: true
    },
    orderBy: { createdAt: 'desc' },
    take: 50
  });

  return messages;
}
