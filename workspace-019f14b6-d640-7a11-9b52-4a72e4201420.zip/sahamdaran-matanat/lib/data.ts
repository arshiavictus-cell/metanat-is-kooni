import { prisma } from '@/lib/prisma';

export async function getConversations(userId: string) {
  const conversations = await prisma.conversation.findMany({
    where: {
      members: {
        some: { userId }
      }
    },
    include: {
      members: { include: { user: true } },
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 1,
        include: {
          seenBy: true
        }
      }
    },
    orderBy: { updatedAt: 'desc' }
  });

  return await Promise.all(conversations.map(async (conversation) => {
    const others = conversation.members.filter((member) => member.userId !== userId).map((member) => member.user.name);
    const unreadCount = await prisma.message.count({
      where: {
        conversationId: conversation.id,
        senderId: { not: userId },
        deletedAt: null,
        seenBy: {
          none: { userId }
        }
      }
    });

    return {
      ...conversation,
      displayTitle: conversation.type === 'GROUP' ? (conversation.title || 'گروه بدون نام') : (others[0] || 'گفت‌وگوی شخصی'),
      lastMessage: conversation.messages[0]?.content,
      unreadCount
    };
  }));
}

export async function getConversationById(conversationId: string, userId: string) {
  const conversation = await prisma.conversation.findFirst({
    where: {
      id: conversationId,
      members: { some: { userId } }
    },
    include: {
      members: { include: { user: true } },
      messages: {
        include: {
          sender: true,
          replyTo: { include: { sender: true } },
          forwardedFrom: { include: { sender: true } },
          seenBy: { include: { user: true } },
          deliveredTo: { include: { user: true } }
        },
        orderBy: { createdAt: 'asc' }
      },
      calls: {
        orderBy: { startedAt: 'desc' },
        take: 10
      }
    }
  });

  if (!conversation) return null;
  const others = conversation.members.filter((member) => member.userId !== userId).map((member) => member.user.name);

  return {
    ...conversation,
    displayTitle: conversation.type === 'GROUP' ? (conversation.title || 'گروه بدون نام') : (others[0] || 'گفت‌وگوی شخصی')
  };
}
