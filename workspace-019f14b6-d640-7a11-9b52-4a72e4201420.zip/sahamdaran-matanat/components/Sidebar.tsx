import Link from 'next/link';
import { Avatar } from '@/components/Avatar';
import { SearchPanel } from '@/components/SearchPanel';

export function Sidebar({ conversations, currentId }: { conversations: any[]; currentId?: string }) {
  return (
    <aside className="sidebar">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <div>
          <div className="badge">سهامداران متانت</div>
          <h2 style={{ margin: '14px 0 4px' }}>گفت‌وگوها</h2>
          <p style={{ margin: 0, color: 'var(--muted)', fontSize: 14 }}>چت خصوصی، گروه و فایل</p>
        </div>
        <Link className="btn btn-secondary" href="/new-chat">جدید</Link>
      </div>

      <SearchPanel />

      <div>
        {conversations.map((item) => (
          <Link href={`/chat/${item.id}`} key={item.id} className="chat-list-item" style={{ outline: currentId === item.id ? '1px solid rgba(45,212,191,.4)' : 'none' }}>
            <Avatar name={item.displayTitle} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 700, display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <span>{item.displayTitle}</span>
                {item.unreadCount ? <span className="badge" style={{ padding: '4px 8px', fontSize: 11 }}>{item.unreadCount}</span> : null}
              </div>
              <div style={{ color: 'var(--muted)', fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {item.lastMessage || 'هنوز پیامی ارسال نشده است'}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </aside>
  );
}
