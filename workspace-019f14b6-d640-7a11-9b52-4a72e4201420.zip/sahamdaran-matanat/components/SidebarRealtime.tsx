'use client';

import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { Sidebar } from '@/components/Sidebar';

export function SidebarRealtime({ initialConversations, currentId, sessionUserId }: { initialConversations: any[]; currentId?: string; sessionUserId: string }) {
  const [conversations, setConversations] = useState(initialConversations);

  useEffect(() => {
    const socket = io({ path: '/api/socket_io' });

    socket.on('conversation:updated', (payload) => {
      setConversations((prev) => {
        const existing = prev.find((item) => item.id === payload.id);
        if (!existing) return prev;

        const displayTitle = payload.type === 'GROUP'
          ? (payload.title || 'گروه بدون نام')
          : (payload.members.find((m: any) => m.userId !== sessionUserId)?.name || 'گفت‌وگوی شخصی');

        const updated = prev.map((item) => item.id === payload.id ? {
          ...item,
          displayTitle,
          lastMessage: payload.lastMessage,
          updatedAt: payload.updatedAt
        } : item);

        return [...updated].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      });
    });

    return () => socket.disconnect();
  }, [sessionUserId]);

  return <Sidebar conversations={conversations} currentId={currentId} />;
}
