import { getInitials } from '@/lib/utils';

export function Avatar({ name }: { name: string }) {
  return <div className="avatar">{getInitials(name)}</div>;
}
