'use client';

import { useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';

function detectType(file?: File | null) {
  if (!file) return 'TEXT';
  if (file.type.startsWith('image/')) return 'IMAGE';
  if (file.type.startsWith('audio/')) return 'AUDIO';
  return 'FILE';
}

export function MessageComposer({
  conversationId,
  replyToId,
  replyPreview,
  editingMessage,
  onSubmitEdit,
  onCancelEdit,
  onClearReply,
  sessionUserId,
  sessionUserName
}: {
  conversationId: string;
  replyToId?: string;
  replyPreview?: any;
  editingMessage?: any;
  onSubmitEdit?: (content: string) => void;
  onCancelEdit?: () => void;
  onClearReply?: () => void;
  sessionUserId: string;
  sessionUserName: string;
}) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [typing, setTyping] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const socketRef = useRef<Socket | null>(null);
  const typingTimeout = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const socket = io({ path: '/api/socket_io' });
    socketRef.current = socket;
    return () => socket.disconnect();
  }, []);

  useEffect(() => {
    if (editingMessage) {
      setContent(editingMessage.content || '');
    }
  }, [editingMessage]);

  function handleTyping(value: string) {
    setContent(value);
    if (!socketRef.current) return;

    if (!typing) {
      setTyping(true);
      socketRef.current.emit('typing:start', { conversationId, userId: sessionUserId, name: sessionUserName });
    }

    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => {
      setTyping(false);
      socketRef.current?.emit('typing:stop', { conversationId, userId: sessionUserId, name: sessionUserName });
    }, 1200);
  }

  async function uploadFile(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch('/api/upload', { method: 'POST', body: formData });
    return res.json();
  }

  async function submitMessage(e: React.FormEvent) {
    e.preventDefault();

    if (editingMessage) {
      if (!content.trim()) return;
      onSubmitEdit?.(content.trim());
      setContent('');
      onCancelEdit?.();
      return;
    }

    const file = fileRef.current?.files?.[0];
    if (!content.trim() && !file) return;
    setLoading(true);

    let uploaded: any = null;
    if (file) {
      uploaded = await uploadFile(file);
    }

    socketRef.current?.emit('message:send', {
      conversationId,
      senderId: sessionUserId,
      content,
      replyToId,
      attachmentUrl: uploaded?.url,
      attachmentName: uploaded?.name,
      attachmentMime: uploaded?.mime,
      type: uploaded?.type || (file ? detectType(file) : 'TEXT')
    });

    setContent('');
    if (fileRef.current) fileRef.current.value = '';
    setLoading(false);
    setTyping(false);
    socketRef.current?.emit('typing:stop', { conversationId, userId: sessionUserId, name: sessionUserName });
    onClearReply?.();
  }

  return (
    <form className="composer" onSubmit={submitMessage} style={{ gridTemplateColumns: '1fr auto auto' }}>
      <div>
        {editingMessage ? (
          <div className="card" style={{ padding: 10, marginBottom: 10, borderRadius: 14 }}>
            <div style={{ fontSize: 12, color: '#fcd34d' }}>در حال ویرایش پیام</div>
            <button type="button" className="btn btn-secondary" style={{ marginTop: 8, padding: '6px 10px' }} onClick={() => { setContent(''); onCancelEdit?.(); }}>
              لغو ویرایش
            </button>
          </div>
        ) : replyPreview ? (
          <div className="card" style={{ padding: 10, marginBottom: 10, borderRadius: 14 }}>
            <div style={{ fontSize: 12, color: '#7dd3fc' }}>در حال پاسخ به {replyPreview.sender?.name || 'پیام'}</div>
            <div style={{ fontSize: 13 }}>{replyPreview.content}</div>
          </div>
        ) : null}
        <input className="input" placeholder={editingMessage ? 'ویرایش پیام...' : 'پیام خود را بنویسید...'} value={content} onChange={(e) => handleTyping(e.target.value)} />
      </div>
      <input ref={fileRef} type="file" className="input" style={{ maxWidth: 220, padding: 10, opacity: editingMessage ? 0.5 : 1 }} disabled={!!editingMessage} />
      <button className="btn btn-primary" disabled={loading}>{loading ? '...' : editingMessage ? 'ذخیره' : 'ارسال'}</button>
    </form>
  );
}
