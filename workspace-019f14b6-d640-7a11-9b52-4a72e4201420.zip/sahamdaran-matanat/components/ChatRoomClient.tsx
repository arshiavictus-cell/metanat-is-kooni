'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import { Avatar } from '@/components/Avatar';
import { formatTime } from '@/lib/utils';
import { MessageComposer } from '@/components/MessageComposer';
import { CallPanel } from '@/components/CallPanel';

type ReceiptUser = { userId: string; deliveredAt?: string; seenAt?: string; user?: { name: string } };
type MessageItem = {
  id: string;
  content: string;
  type: 'TEXT' | 'FILE' | 'IMAGE' | 'AUDIO' | 'SYSTEM';
  createdAt: string;
  updatedAt?: string;
  senderId: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  isEdited?: boolean;
  deletedAt?: string | null;
  seenBy?: ReceiptUser[];
  deliveredTo?: ReceiptUser[];
  sender: { name: string };
  replyTo?: { id: string; content: string; sender: { name: string } } | null;
  forwardedFrom?: { id: string; content: string; sender: { name: string } } | null;
};

export function ChatRoomClient({ sessionUserId, sessionUserName, conversation }: { sessionUserId: string; sessionUserName: string; conversation: any }) {
  const [messages, setMessages] = useState<MessageItem[]>(conversation.messages);
  const [replyTo, setReplyTo] = useState<any>(null);
  const [editingMessage, setEditingMessage] = useState<MessageItem | null>(null);
  const [onlineCount, setOnlineCount] = useState(0);
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({});
  const socketRef = useRef<Socket | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const socket = io({ path: '/api/socket_io' });
    socketRef.current = socket;

    socket.emit('join-conversation', {
      conversationId: conversation.id,
      userId: sessionUserId
    });

    socket.on('message:new', (message: MessageItem) => {
      setMessages((prev) => [...prev, message]);
      socket.emit('message:seen', { conversationId: conversation.id, messageId: message.id, userId: sessionUserId });
    });

    socket.on('message:updated', (updated: MessageItem) => {
      setMessages((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
    });

    socket.on('message:deleted', (deleted: MessageItem) => {
      setMessages((prev) => prev.map((item) => (item.id === deleted.id ? deleted : item)));
    });

    socket.on('presence:update', ({ onlineCount }) => {
      setOnlineCount(onlineCount);
    });

    socket.on('typing:update', ({ userId, name, isTyping }) => {
      if (userId === sessionUserId) return;
      setTypingUsers((prev) => {
        const next = { ...prev };
        if (isTyping) next[userId] = name;
        else delete next[userId];
        return next;
      });
    });

    socket.on('message:seen:update', ({ messageId, userId, seenAt }) => {
      setMessages((prev) => prev.map((item) => {
        if (item.id !== messageId) return item;
        const seenBy = item.seenBy || [];
        const exists = seenBy.some((entry: any) => entry.userId === userId);
        if (exists) return item;
        return { ...item, seenBy: [...seenBy, { userId, seenAt }] };
      }));
    });

    return () => {
      socket.disconnect();
    };
  }, [conversation.id, sessionUserId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const title = useMemo(() => conversation.displayTitle, [conversation.displayTitle]);
  const typingText = Object.values(typingUsers).filter(Boolean).join('، ');

  function handleEdit(message: MessageItem) {
    setEditingMessage(message);
    setReplyTo(null);
  }

  function submitEdit(content: string) {
    if (!editingMessage || !socketRef.current) return;
    socketRef.current.emit('message:edit', {
      conversationId: conversation.id,
      messageId: editingMessage.id,
      userId: sessionUserId,
      content
    });
    setEditingMessage(null);
  }

  function deleteMessage(messageId: string) {
    socketRef.current?.emit('message:delete', {
      conversationId: conversation.id,
      messageId,
      userId: sessionUserId
    });
  }

  return (
    <>
      <div className="topbar">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Avatar name={title} />
          <div>
            <div style={{ fontWeight: 700 }}>{title}</div>
            <div style={{ color: 'var(--muted)', fontSize: 13 }}>
              {conversation.type === 'GROUP' ? 'گروه' : 'چت خصوصی'} • {onlineCount} آنلاین
            </div>
            {typingText ? <div style={{ color: '#7dd3fc', fontSize: 12 }}>{typingText} در حال تایپ...</div> : null}
          </div>
        </div>
      </div>

      <CallPanel conversationId={conversation.id} sessionUserId={sessionUserId} />

      <div className="messages">
        {messages.map((message) => {
          const own = message.senderId === sessionUserId;
          const seenCount = (message.seenBy || []).filter((item: any) => item.userId !== sessionUserId).length;
          const deliveredCount = (message.deliveredTo || []).filter((item: any) => item.userId !== sessionUserId).length;
          return (
            <div key={message.id} className={`message-bubble ${own ? 'message-own' : 'message-other'}`}>
              {!own ? <div style={{ fontSize: 13, color: '#7dd3fc', marginBottom: 6 }}>{message.sender.name}</div> : null}

              {message.forwardedFrom ? (
                <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 8, borderRight: '2px solid rgba(255,255,255,.25)', paddingRight: 8 }}>
                  فوروارد شده از {message.forwardedFrom.sender.name}
                </div>
              ) : null}

              {message.replyTo ? (
                <div style={{ fontSize: 12, opacity: 0.9, marginBottom: 8, background: 'rgba(255,255,255,.08)', borderRadius: 12, padding: 8 }}>
                  <div style={{ color: '#7dd3fc' }}>{message.replyTo.sender.name}</div>
                  <div>{message.replyTo.content}</div>
                </div>
              ) : null}

              {message.deletedAt ? (
                <div style={{ opacity: 0.7, fontStyle: 'italic' }}>{message.content}</div>
              ) : message.type === 'IMAGE' && message.attachmentUrl ? (
                <div>
                  <img src={message.attachmentUrl} alt={message.attachmentName || 'image'} style={{ maxWidth: 280, borderRadius: 14, marginBottom: 8 }} />
                  {message.content ? <div>{message.content}</div> : null}
                </div>
              ) : message.type === 'AUDIO' && message.attachmentUrl ? (
                <div>
                  <audio controls src={message.attachmentUrl} style={{ width: 260 }} />
                  {message.content ? <div style={{ marginTop: 8 }}>{message.content}</div> : null}
                </div>
              ) : message.type === 'FILE' && message.attachmentUrl ? (
                <div>
                  <a href={message.attachmentUrl} target="_blank" className="badge">دانلود {message.attachmentName || 'فایل'}</a>
                  {message.content ? <div style={{ marginTop: 8 }}>{message.content}</div> : null}
                </div>
              ) : (
                <div>{message.content}</div>
              )}

              <div style={{ display: 'flex', gap: 8, alignItems: 'center', justifyContent: 'space-between', marginTop: 8, flexWrap: 'wrap' }}>
                <div style={{ fontSize: 11, opacity: 0.75 }}>
                  {formatTime(message.createdAt)}
                  {message.isEdited ? ' • ویرایش‌شده' : ''}
                  {own ? ` • ${seenCount > 0 ? `دیده‌شده توسط ${seenCount}` : deliveredCount > 0 ? `تحویل‌شده به ${deliveredCount}` : 'ارسال‌شده'}` : ''}
                </div>
                {!message.deletedAt ? (
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button className="btn btn-secondary" type="button" style={{ padding: '6px 10px' }} onClick={() => setReplyTo(message)}>ریپلای</button>
                    <form action="/api/messages/forward" method="post">
                      <input type="hidden" name="messageId" value={message.id} />
                      <input type="hidden" name="conversationId" value={conversation.id} />
                      <button className="btn btn-secondary" style={{ padding: '6px 10px' }}>فوروارد</button>
                    </form>
                    {own ? <button className="btn btn-secondary" type="button" style={{ padding: '6px 10px' }} onClick={() => handleEdit(message)}>ویرایش</button> : null}
                    {own ? <button className="btn btn-secondary" type="button" style={{ padding: '6px 10px' }} onClick={() => deleteMessage(message.id)}>حذف</button> : null}
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <MessageComposer
        conversationId={conversation.id}
        replyToId={replyTo?.id}
        replyPreview={replyTo}
        editingMessage={editingMessage}
        onSubmitEdit={submitEdit}
        onCancelEdit={() => setEditingMessage(null)}
        onClearReply={() => setReplyTo(null)}
        sessionUserId={sessionUserId}
        sessionUserName={sessionUserName}
      />
    </>
  );
}
