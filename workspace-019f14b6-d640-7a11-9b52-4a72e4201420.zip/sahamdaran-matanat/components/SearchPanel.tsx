'use client';

import { useState } from 'react';

export function SearchPanel() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function onSearch(value: string) {
    setQ(value);
    if (!value.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    const res = await fetch(`/api/search?q=${encodeURIComponent(value)}`);
    const data = await res.json();
    setResults(data.results || []);
    setLoading(false);
  }

  return (
    <div className="card" style={{ padding: 16, marginBottom: 16 }}>
      <input className="input" placeholder="جستجوی پیام‌ها..." value={q} onChange={(e) => onSearch(e.target.value)} />
      {loading ? <div style={{ marginTop: 10, color: 'var(--muted)' }}>در حال جستجو...</div> : null}
      {results.length ? (
        <div style={{ marginTop: 12, display: 'grid', gap: 10, maxHeight: 260, overflow: 'auto' }}>
          {results.map((item) => (
            <a key={item.id} href={`/chat/${item.conversationId}`} className="chat-list-item">
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700 }}>{item.sender.name}</div>
                <div style={{ color: 'var(--muted)', fontSize: 13 }}>{item.content}</div>
              </div>
            </a>
          ))}
        </div>
      ) : q && !loading ? <div style={{ marginTop: 10, color: 'var(--muted)' }}>نتیجه‌ای پیدا نشد.</div> : null}
    </div>
  );
}
