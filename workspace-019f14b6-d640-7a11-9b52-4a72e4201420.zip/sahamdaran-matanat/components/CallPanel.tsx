'use client';

import { useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';

const rtcConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' }
  ]
};

export function CallPanel({ conversationId, sessionUserId }: { conversationId: string; sessionUserId: string }) {
  const [incomingCall, setIncomingCall] = useState<any>(null);
  const [activeCall, setActiveCall] = useState<any>(null);
  const [callStatus, setCallStatus] = useState('');
  const [callType, setCallType] = useState<'AUDIO' | 'VIDEO'>('AUDIO');
  const socketRef = useRef<Socket | null>(null);
  const peerRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const socket = io({ path: '/api/socket_io' });
    socketRef.current = socket;

    socket.on('call:incoming', (payload) => {
      if (payload.initiatedById !== sessionUserId) {
        setIncomingCall(payload);
        setCallType(payload.type);
        setCallStatus(payload.type === 'VIDEO' ? 'تماس تصویری ورودی' : 'تماس صوتی ورودی');
      }
    });

    socket.on('call:accepted', async ({ callId }) => {
      if (!activeCall || activeCall.callId !== callId) return;
      setCallStatus('تماس پذیرفته شد');
      await createOffer();
    });

    socket.on('call:rejected', () => {
      setCallStatus('تماس رد شد');
      cleanupCall();
    });

    socket.on('call:ended', () => {
      setCallStatus('تماس پایان یافت');
      cleanupCall();
    });

    socket.on('webrtc:offer', async ({ offer }) => {
      await ensurePeer();
      await peerRef.current?.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await peerRef.current?.createAnswer();
      if (answer) {
        await peerRef.current?.setLocalDescription(answer);
        socket.emit('webrtc:answer', { conversationId, answer, fromUserId: sessionUserId });
      }
    });

    socket.on('webrtc:answer', async ({ answer }) => {
      await peerRef.current?.setRemoteDescription(new RTCSessionDescription(answer));
    });

    socket.on('webrtc:ice-candidate', async ({ candidate }) => {
      if (candidate) await peerRef.current?.addIceCandidate(new RTCIceCandidate(candidate));
    });

    return () => socket.disconnect();
  }, [conversationId, sessionUserId, activeCall]);

  async function ensurePeer(video = callType === 'VIDEO') {
    if (peerRef.current) return;
    const peer = new RTCPeerConnection(rtcConfig);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video });
    localStreamRef.current = stream;
    stream.getTracks().forEach((track) => peer.addTrack(track, stream));

    if (localVideoRef.current && video) {
      localVideoRef.current.srcObject = stream;
    }

    peer.ontrack = (event) => {
      const [remoteStream] = event.streams;
      if (remoteVideoRef.current && video) remoteVideoRef.current.srcObject = remoteStream;
      if (remoteAudioRef.current) remoteAudioRef.current.srcObject = remoteStream;
    };

    peer.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current?.emit('webrtc:ice-candidate', {
          conversationId,
          candidate: event.candidate,
          fromUserId: sessionUserId
        });
      }
    };

    peerRef.current = peer;
  }

  async function createOffer() {
    await ensurePeer();
    const offer = await peerRef.current?.createOffer();
    if (offer) {
      await peerRef.current?.setLocalDescription(offer);
      socketRef.current?.emit('webrtc:offer', { conversationId, offer, fromUserId: sessionUserId });
    }
  }

  function cleanupCall() {
    peerRef.current?.close();
    peerRef.current = null;
    localStreamRef.current?.getTracks().forEach((track) => track.stop());
    localStreamRef.current = null;
    setIncomingCall(null);
    setActiveCall(null);
  }

  function startCall(type: 'AUDIO' | 'VIDEO') {
    setCallType(type);
    setCallStatus(type === 'VIDEO' ? 'در حال برقراری تماس تصویری...' : 'در حال برقراری تماس صوتی...');
    socketRef.current?.emit('call:initiate', { conversationId, initiatedById: sessionUserId, type });
    setActiveCall({ conversationId, type, isCaller: true });
  }

  function acceptCall() {
    if (!incomingCall) return;
    setActiveCall({ ...incomingCall, isCaller: false });
    socketRef.current?.emit('call:accept', { callId: incomingCall.callId, conversationId, userId: sessionUserId });
    setIncomingCall(null);
  }

  function rejectCall() {
    if (!incomingCall) return;
    socketRef.current?.emit('call:reject', { callId: incomingCall.callId, conversationId, userId: sessionUserId });
    setIncomingCall(null);
    setCallStatus('تماس رد شد');
  }

  function endCall() {
    const callId = activeCall?.callId;
    if (callId) {
      socketRef.current?.emit('call:end', { callId, conversationId, userId: sessionUserId });
    }
    cleanupCall();
  }

  return (
    <div className="card" style={{ padding: 12, margin: '12px 24px 0' }}>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button className="btn btn-secondary" type="button" onClick={() => startCall('AUDIO')}>تماس صوتی واقعی</button>
        <button className="btn btn-secondary" type="button" onClick={() => startCall('VIDEO')}>تماس تصویری واقعی</button>
        {activeCall ? <button className="btn" style={{ background: '#7f1d1d', color: 'white' }} type="button" onClick={endCall}>پایان تماس</button> : null}
      </div>
      {callStatus ? <div style={{ marginTop: 10, color: 'var(--muted)' }}>{callStatus}</div> : null}
      {incomingCall ? (
        <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
          <button className="btn btn-primary" type="button" onClick={acceptCall}>پاسخ</button>
          <button className="btn btn-secondary" type="button" onClick={rejectCall}>رد</button>
        </div>
      ) : null}
      <audio ref={remoteAudioRef} autoPlay />
      <div style={{ display: callType === 'VIDEO' ? 'grid' : 'none', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 10 }}>
        <video ref={localVideoRef} autoPlay muted playsInline style={{ width: '100%', borderRadius: 14, background: '#000' }} />
        <video ref={remoteVideoRef} autoPlay playsInline style={{ width: '100%', borderRadius: 14, background: '#000' }} />
      </div>
    </div>
  );
}
