const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { query } = require('../db/connection');
const { generateToken, authMiddleware } = require('../middleware/auth');

// ثبت‌نام
router.post('/register', async (req, res, next) => {
  try {
    const { username, phone, password, display_name } = req.body;

    if (!username || !phone || !password) {
      return res.status(400).json({ error: 'نام کاربری، شماره تلفن و رمز عبور الزامی هستند.' });
    }

    if (username.length < 3) {
      return res.status(400).json({ error: 'نام کاربری باید حداقل ۳ کاراکتر باشد.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'رمز عبور باید حداقل ۶ کاراکتر باشد.' });
    }

    if (!/^09\d{9}$/.test(phone)) {
      return res.status(400).json({ error: 'شماره تلفن باید با ۰۹ شروع شده و ۱۱ رقم باشد.' });
    }

    // بررسی تکراری نبودن
    const existing = await query(
      'SELECT id FROM users WHERE phone = $1 OR username = $2',
      [phone, username]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'این نام کاربری یا شماره تلفن قبلاً ثبت شده است.' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const defaultAvatar = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(username)}&backgroundColor=0088cc,1a73e8,34a853,ea4335,fbbc04`;

    const result = await query(
      `INSERT INTO users (username, phone, password_hash, display_name, avatar_url)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, username, phone, display_name, avatar_url, bio, created_at`,
      [username, phone, password_hash, display_name || username, defaultAvatar]
    );

    const user = result.rows[0];
    const token = generateToken(user);

    res.json({
      success: true,
      message: 'حساب کاربری شما با موفقیت ایجاد شد.',
      token,
      user
    });
  } catch (err) {
    next(err);
  }
});

// ورود
router.post('/login', async (req, res, next) => {
  try {
    const { phone, password } = req.body;

    if (!phone || !password) {
      return res.status(400).json({ error: 'شماره تلفن و رمز عبور الزامی هستند.' });
    }

    const result = await query(
      'SELECT * FROM users WHERE phone = $1',
      [phone]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'شماره تلفن یا رمز عبور اشتباه است.' });
    }

    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);

    if (!valid) {
      return res.status(401).json({ error: 'شماره تلفن یا رمز عبور اشتباه است.' });
    }

    await query('UPDATE users SET is_online = true, last_seen = NOW() WHERE id = $1', [user.id]);

    const token = generateToken(user);
    delete user.password_hash;

    res.json({
      success: true,
      message: 'با موفقیت وارد شدید.',
      token,
      user
    });
  } catch (err) {
    next(err);
  }
});

// خروج
router.post('/logout', authMiddleware, async (req, res, next) => {
  try {
    await query('UPDATE users SET is_online = false, last_seen = NOW() WHERE id = $1', [req.user.id]);
    res.json({ success: true, message: 'با موفقیت خارج شدید.' });
  } catch (err) {
    next(err);
  }
});

// بررسی نشست
router.get('/me', authMiddleware, async (req, res, next) => {
  try {
    const result = await query(
      'SELECT id, username, phone, display_name, avatar_url, bio, is_online, last_seen, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'کاربر یافت نشد.' });
    }
    res.json({ user: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
