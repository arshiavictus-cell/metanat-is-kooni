const express = require('express');
const router = express.Router();
const { query } = require('../db/connection');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// دریافت پیام‌های یک گفتگو
router.get('/chat/:chatId', async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    const before = parseInt(req.query.before) || null;

    // بررسی عضویت
    const member = await query(
      'SELECT 1 FROM chat_members WHERE chat_id = $1 AND user_id = $2',
      [chatId, req.user.id]
    );
    if (member.rows.length === 0) {
      return res.status(403).json({ error: 'شما به این گفتگو دسترسی ندارید.' });
    }

    let queryText = `
      SELECT
        m.*,
        u.username as sender_username,
        u.display_name as sender_name,
        u.avatar_url as sender_avatar,
        (
          SELECT COUNT(*) FROM message_reads WHERE message_id = m.id
        ) as read_count
      FROM messages m
      LEFT JOIN users u ON u.id = m.sender_id
      WHERE m.chat_id = $1 AND m.is_deleted = false
    `;
    const params = [chatId];

    if (before) {
      queryText += ' AND m.id < $2';
      params.push(before);
    }

    queryText += ' ORDER BY m.created_at DESC LIMIT $' + (params.length + 1);
    params.push(limit);

    const result = await query(queryText, params);
    const messages = result.rows.reverse();

    // به‌روزرسانی آخرین پیام خوانده شده
    if (messages.length > 0) {
      const lastId = messages[messages.length - 1].id;
      await query(
        'UPDATE chat_members SET last_read_message_id = $1 WHERE chat_id = $2 AND user_id = $3',
        [lastId, chatId, req.user.id]
      );
      // ثبت خوانده شدن پیام‌ها
      for (const msg of messages) {
        if (msg.sender_id !== req.user.id) {
          await query(
            `INSERT INTO message_reads (message_id, user_id) VALUES ($1, $2)
             ON CONFLICT DO NOTHING`,
            [msg.id, req.user.id]
          );
        }
      }
    }

    res.json({ messages });
  } catch (err) {
    next(err);
  }
});

// ارسال پیام (REST - سوکت هم این کار را می‌کند)
router.post('/send', async (req, res, next) => {
  try {
    const { chat_id, content, message_type, file_url, file_name, file_size, reply_to } = req.body;

    if (!chat_id) {
      return res.status(400).json({ error: 'شناسه گفتگو الزامی است.' });
    }
    if (!content && !file_url) {
      return res.status(400).json({ error: 'پیام نمی‌تواند خالی باشد.' });
    }

    // بررسی عضویت و عدم مسدود بودن
    const member = await query(
      `SELECT 1 FROM chat_members WHERE chat_id = $1 AND user_id = $2`,
      [chat_id, req.user.id]
    );
    if (member.rows.length === 0) {
      return res.status(403).json({ error: 'شما به این گفتگو دسترسی ندارید.' });
    }

    const result = await query(
      `INSERT INTO messages (chat_id, sender_id, content, message_type, file_url, file_name, file_size, reply_to)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [chat_id, req.user.id, content || '', message_type || 'text', file_url || null, file_name || null, file_size || null, reply_to || null]
    );

    // اطلاعات فرستنده
    const userInfo = await query(
      'SELECT username, display_name, avatar_url FROM users WHERE id = $1',
      [req.user.id]
    );

    const message = {
      ...result.rows[0],
      sender_username: userInfo.rows[0].username,
      sender_name: userInfo.rows[0].display_name,
      sender_avatar: userInfo.rows[0].avatar_url,
      read_count: 0
    };

    res.json({ success: true, message });
  } catch (err) {
    next(err);
  }
});

// ویرایش پیام
router.put('/:id', async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: 'متن پیام نمی‌تواند خالی باشد.' });
    }
    const result = await query(
      `UPDATE messages SET content = $1, is_edited = true, updated_at = NOW()
       WHERE id = $2 AND sender_id = $3
       RETURNING *`,
      [content, req.params.id, req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(403).json({ error: 'شما مجاز به ویرایش این پیام نیستید.' });
    }
    res.json({ success: true, message: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// حذف پیام
router.delete('/:id', async (req, res, next) => {
  try {
    const result = await query(
      `UPDATE messages SET is_deleted = true, content = NULL, file_url = NULL
       WHERE id = $1 AND sender_id = $2
       RETURNING id, chat_id`,
      [req.params.id, req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(403).json({ error: 'شما مجاز به حذف این پیام نیستید.' });
    }
    res.json({ success: true, message: 'پیام حذف شد.' });
  } catch (err) {
    next(err);
  }
});

// جستجو در پیام‌ها
router.get('/search/:chatId', async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) {
      return res.json({ messages: [] });
    }
    const result = await query(
      `SELECT m.*, u.display_name as sender_name
       FROM messages m
       LEFT JOIN users u ON u.id = m.sender_id
       WHERE m.chat_id = $1 AND m.content ILIKE $2 AND m.is_deleted = false
       ORDER BY m.created_at DESC
       LIMIT 50`,
      [req.params.chatId, `%${q}%`]
    );
    res.json({ messages: result.rows });
  } catch (err) {
    next(err);
  }
});

// علامت‌گذاری همه پیام‌ها به عنوان خوانده شده
router.post('/read/:chatId', async (req, res, next) => {
  try {
    const messages = await query(
      `SELECT id FROM messages WHERE chat_id = $1 AND sender_id != $2 AND is_deleted = false`,
      [req.params.chatId, req.user.id]
    );
    for (const msg of messages.rows) {
      await query(
        `INSERT INTO message_reads (message_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
        [msg.id, req.user.id]
      );
    }
    if (messages.rows.length > 0) {
      const lastId = messages.rows[messages.rows.length - 1].id;
      await query(
        'UPDATE chat_members SET last_read_message_id = $1 WHERE chat_id = $2 AND user_id = $3',
        [lastId, req.params.chatId, req.user.id]
      );
    }
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
