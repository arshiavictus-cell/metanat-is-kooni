const express = require('express');
const router = express.Router();
const { query } = require('../db/connection');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// جستجوی کاربر
router.get('/search', async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) {
      return res.json({ users: [] });
    }

    const result = await query(
      `SELECT id, username, phone, display_name, avatar_url, bio, is_online, last_seen
       FROM users
       WHERE id != $1 AND (
         username ILIKE $2 OR
         phone LIKE $2 OR
         display_name ILIKE $2
       )
       LIMIT 20`,
      [req.user.id, `%${q}%`]
    );

    res.json({ users: result.rows });
  } catch (err) {
    next(err);
  }
});

// دریافت اطلاعات یک کاربر
router.get('/:id', async (req, res, next) => {
  try {
    const result = await query(
      'SELECT id, username, phone, display_name, avatar_url, bio, is_online, last_seen, created_at FROM users WHERE id = $1',
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'کاربر یافت نشد.' });
    }
    res.json({ user: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// ویرایش پروفایل
router.put('/me', async (req, res, next) => {
  try {
    const { display_name, bio, avatar_url } = req.body;
    const updates = [];
    const values = [];
    let i = 1;

    if (display_name !== undefined) {
      updates.push(`display_name = $${i++}`);
      values.push(display_name);
    }
    if (bio !== undefined) {
      updates.push(`bio = $${i++}`);
      values.push(bio);
    }
    if (avatar_url !== undefined) {
      updates.push(`avatar_url = $${i++}`);
      values.push(avatar_url);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'هیچ فیلدی برای به‌روزرسانی ارسال نشده است.' });
    }

    values.push(req.user.id);
    const result = await query(
      `UPDATE users SET ${updates.join(', ')} WHERE id = $${i}
       RETURNING id, username, phone, display_name, avatar_url, bio`,
      values
    );

    res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// لیست مخاطبین
router.get('/contacts/list', async (req, res, next) => {
  try {
    const result = await query(
      `SELECT u.id, u.username, u.phone, u.display_name, u.avatar_url, u.is_online, u.last_seen, c.nickname
       FROM contacts c
       JOIN users u ON u.id = c.contact_id
       WHERE c.user_id = $1
       ORDER BY u.is_online DESC, u.display_name`,
      [req.user.id]
    );
    res.json({ contacts: result.rows });
  } catch (err) {
    next(err);
  }
});

// افزودن مخاطب
router.post('/contacts/add', async (req, res, next) => {
  try {
    const { contact_id, nickname } = req.body;
    if (!contact_id) {
      return res.status(400).json({ error: 'شناسه مخاطب الزامی است.' });
    }
    if (parseInt(contact_id) === req.user.id) {
      return res.status(400).json({ error: 'نمی‌توانید خود را به مخاطبین اضافه کنید.' });
    }
    await query(
      `INSERT INTO contacts (user_id, contact_id, nickname)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id, contact_id) DO UPDATE SET nickname = $3`,
      [req.user.id, contact_id, nickname || null]
    );
    res.json({ success: true, message: 'مخاطب با موفقیت اضافه شد.' });
  } catch (err) {
    next(err);
  }
});

// مسدود کردن کاربر
router.post('/block', async (req, res, next) => {
  try {
    const { user_id } = req.body;
    await query(
      `INSERT INTO blocked_users (user_id, blocked_id) VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [req.user.id, user_id]
    );
    res.json({ success: true, message: 'کاربر مسدود شد.' });
  } catch (err) {
    next(err);
  }
});

router.post('/unblock', async (req, res, next) => {
  try {
    const { user_id } = req.body;
    await query('DELETE FROM blocked_users WHERE user_id = $1 AND blocked_id = $2', [req.user.id, user_id]);
    res.json({ success: true, message: 'کاربر از حالت مسدود خارج شد.' });
  } catch (err) {
    next(err);
  }
});

router.get('/blocked/list', async (req, res, next) => {
  try {
    const result = await query(
      `SELECT u.id, u.username, u.display_name, u.avatar_url
       FROM blocked_users b
       JOIN users u ON u.id = b.blocked_id
       WHERE b.user_id = $1`,
      [req.user.id]
    );
    res.json({ blocked: result.rows });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
