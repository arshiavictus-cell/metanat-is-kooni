const express = require('express');
const router = express.Router();
const { query } = require('../db/connection');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// لیست گفتگوهای کاربر
router.get('/', async (req, res, next) => {
  try {
    const result = await query(
      `SELECT
         c.id, c.type, c.name, c.description, c.avatar_url, c.member_count, c.created_at,
         cm.unread_count,
         (
           SELECT m.content FROM messages m
           WHERE m.chat_id = c.id AND m.is_deleted = false
           ORDER BY m.created_at DESC LIMIT 1
         ) as last_message,
         (
           SELECT m.message_type FROM messages m
           WHERE m.chat_id = c.id AND m.is_deleted = false
           ORDER BY m.created_at DESC LIMIT 1
         ) as last_message_type,
         (
           SELECT m.created_at FROM messages m
           WHERE m.chat_id = c.id AND m.is_deleted = false
           ORDER BY m.created_at DESC LIMIT 1
         ) as last_message_time,
         (
           SELECT u.display_name FROM messages m
           JOIN users u ON u.id = m.sender_id
           WHERE m.chat_id = c.id AND m.is_deleted = false
           ORDER BY m.created_at DESC LIMIT 1
         ) as last_sender_name
       FROM chats c
       JOIN chat_members cm ON cm.chat_id = c.id
       WHERE cm.user_id = $1
       ORDER BY last_message_time DESC NULLS LAST`,
      [req.user.id]
    );

    // برای چت‌های خصوصی، نام و آواتار طرف مقابل را بگیر
    const chats = await Promise.all(result.rows.map(async (chat) => {
      if (chat.type === 'private') {
        const other = await query(
          `SELECT u.id, u.display_name, u.avatar_url, u.is_online, u.last_seen, u.username
           FROM chat_members cm
           JOIN users u ON u.id = cm.user_id
           WHERE cm.chat_id = $1 AND cm.user_id != $2`,
          [chat.id, req.user.id]
        );
        if (other.rows.length > 0) {
          chat.name = other.rows[0].display_name;
          chat.avatar_url = other.rows[0].avatar_url;
          chat.other_user = other.rows[0];
        }
      }
      return chat;
    }));

    res.json({ chats });
  } catch (err) {
    next(err);
  }
});

// ایجاد یا دریافت گفتگوی خصوصی
router.post('/private', async (req, res, next) => {
  try {
    const { user_id } = req.body;
    if (!user_id) {
      return res.status(400).json({ error: 'شناسه کاربر الزامی است.' });
    }

    if (parseInt(user_id) === req.user.id) {
      return res.status(400).json({ error: 'نمی‌توانید با خودتان گفتگو کنید.' });
    }

    // بررسی اینکه گفتگوی خصوصی از قبل وجود دارد یا نه
    const existing = await query(
      `SELECT c.id FROM chats c
       WHERE c.type = 'private'
         AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = $1)
         AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = $2)`,
      [req.user.id, user_id]
    );

    let chatId;
    if (existing.rows.length > 0) {
      chatId = existing.rows[0].id;
    } else {
      const newChat = await query(
        `INSERT INTO chats (type, created_by, member_count) VALUES ('private', $1, 2) RETURNING id`,
        [req.user.id]
      );
      chatId = newChat.rows[0].id;
      await query(
        `INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2), ($1, $3)`,
        [chatId, req.user.id, user_id]
      );
    }

    res.json({ success: true, chat_id: chatId });
  } catch (err) {
    next(err);
  }
});

// ایجاد گروه
router.post('/group', async (req, res, next) => {
  try {
    const { name, description, members } = req.body;
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'نام گروه الزامی است.' });
    }
    if (!members || !Array.isArray(members) || members.length === 0) {
      return res.status(400).json({ error: 'حداقل یک عضو برای گروه الزامی است.' });
    }

    const defaultAvatar = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=0088cc,34a853,ea4335`;
    const newGroup = await query(
      `INSERT INTO chats (type, name, description, avatar_url, created_by, member_count)
       VALUES ('group', $1, $2, $3, $4, $5) RETURNING id`,
      [name.trim(), description || '', defaultAvatar, req.user.id, members.length + 1]
    );
    const chatId = newGroup.rows[0].id;

    // اضافه کردن سازنده به عنوان مدیر
    await query(
      `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'admin')`,
      [chatId, req.user.id]
    );

    // اضافه کردن بقیه اعضا
    for (const memberId of members) {
      if (parseInt(memberId) !== req.user.id) {
        await query(
          `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'member')
           ON CONFLICT DO NOTHING`,
          [chatId, memberId]
        );
      }
    }

    res.json({ success: true, chat_id: chatId, message: 'گروه با موفقیت ایجاد شد.' });
  } catch (err) {
    next(err);
  }
});

// ایجاد کانال
router.post('/channel', async (req, res, next) => {
  try {
    const { name, description, is_public } = req.body;
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'نام کانال الزامی است.' });
    }

    const defaultAvatar = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=0088cc`;
    const newChannel = await query(
      `INSERT INTO chats (type, name, description, avatar_url, created_by, is_public, member_count)
       VALUES ('channel', $1, $2, $3, $4, $5, 1) RETURNING id`,
      [name.trim(), description || '', defaultAvatar, req.user.id, is_public || false]
    );
    const chatId = newChannel.rows[0].id;

    await query(
      `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'admin')`,
      [chatId, req.user.id]
    );

    res.json({ success: true, chat_id: chatId, message: 'کانال با موفقیت ایجاد شد.' });
  } catch (err) {
    next(err);
  }
});

// دریافت اطلاعات یک گفتگو
router.get('/:id', async (req, res, next) => {
  try {
    // بررسی عضویت
    const memberCheck = await query(
      'SELECT role FROM chat_members WHERE chat_id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );
    if (memberCheck.rows.length === 0) {
      return res.status(403).json({ error: 'شما به این گفتگو دسترسی ندارید.' });
    }

    const result = await query(
      'SELECT * FROM chats WHERE id = $1',
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'گفتگو یافت نشد.' });
    }

    const chat = result.rows[0];

    // اعضا
    const members = await query(
      `SELECT u.id, u.username, u.display_name, u.avatar_url, u.is_online, u.last_seen, cm.role, cm.joined_at
       FROM chat_members cm
       JOIN users u ON u.id = cm.user_id
       WHERE cm.chat_id = $1
       ORDER BY cm.role DESC, u.display_name`,
      [req.params.id]
    );
    chat.members = members.rows;
    chat.my_role = memberCheck.rows[0].role;

    res.json({ chat });
  } catch (err) {
    next(err);
  }
});

// افزودن عضو به گروه
router.post('/:id/add-member', async (req, res, next) => {
  try {
    const { user_id } = req.body;

    const roleCheck = await query(
      `SELECT c.type, cm.role FROM chats c
       JOIN chat_members cm ON cm.chat_id = c.id
       WHERE c.id = $1 AND cm.user_id = $2`,
      [req.params.id, req.user.id]
    );
    if (roleCheck.rows.length === 0) {
      return res.status(403).json({ error: 'دسترسی غیرمجاز.' });
    }
    const chat = roleCheck.rows[0];
    if (chat.type !== 'group' && chat.type !== 'channel') {
      return res.status(400).json({ error: 'فقط در گروه‌ها و کانال‌ها می‌توان عضو اضافه کرد.' });
    }

    await query(
      `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'member')
       ON CONFLICT DO NOTHING`,
      [req.params.id, user_id]
    );
    await query(
      'UPDATE chats SET member_count = (SELECT COUNT(*) FROM chat_members WHERE chat_id = $1) WHERE id = $1',
      [req.params.id]
    );

    res.json({ success: true, message: 'عضو با موفقیت اضافه شد.' });
  } catch (err) {
    next(err);
  }
});

// حذف یا ترک گفتگو
router.delete('/:id', async (req, res, next) => {
  try {
    await query('DELETE FROM chat_members WHERE chat_id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    await query(
      'UPDATE chats SET member_count = (SELECT COUNT(*) FROM chat_members WHERE chat_id = $1) WHERE id = $1',
      [req.params.id]
    );
    res.json({ success: true, message: 'از گفتگو خارج شدید.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
