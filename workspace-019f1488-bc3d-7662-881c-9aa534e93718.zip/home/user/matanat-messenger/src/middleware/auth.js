const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'matanat-default-secret-change-me';

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1] || req.cookies?.token || req.query.token;

  if (!token) {
    return res.status(401).json({ error: 'لطفاً ابتدا وارد حساب کاربری خود شوید.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'نشست شما منقضی شده است. لطفاً دوباره وارد شوید.' });
  }
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, phone: user.phone },
    JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
  );
}

module.exports = { authMiddleware, generateToken, JWT_SECRET };
