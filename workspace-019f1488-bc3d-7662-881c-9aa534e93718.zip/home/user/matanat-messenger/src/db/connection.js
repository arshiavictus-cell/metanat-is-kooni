const { Pool } = require('pg');

let pool;

function getPool() {
  if (!pool) {
    const connectionString = process.env.DATABASE_URL;
    if (connectionString) {
      pool = new Pool({
        connectionString,
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
      });
    } else {
      pool = new Pool({
        host: process.env.PGHOST || 'localhost',
        port: parseInt(process.env.PGPORT || '5432'),
        user: process.env.PGUSER || 'postgres',
        password: process.env.PGPASSWORD || 'password',
        database: process.env.PGDATABASE || 'matanat',
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
      });
    }
  }
  return pool;
}

async function query(text, params) {
  const start = Date.now();
  const res = await getPool().query(text, params);
  const duration = Date.now() - start;
  if (process.env.NODE_ENV !== 'production' && duration > 500) {
    console.log('کوئری کند:', { text, duration, rows: res.rowCount });
  }
  return res;
}

async function getClient() {
  return await getPool().connect();
}

async function testConnection() {
  try {
    const result = await query('SELECT NOW() as now, current_database() as db');
    console.log('✅ اتصال به دیتابیس برقرار شد:', result.rows[0].db);
    return true;
  } catch (err) {
    console.error('❌ خطا در اتصال به دیتابیس:', err.message);
    throw err;
  }
}

module.exports = { getPool, query, getClient, testConnection };
