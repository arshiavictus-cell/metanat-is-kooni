const jwt = require('jsonwebtoken');
const { query } = require('../db/connection');
const { JWT_SECRET } = require('../middleware/auth');

const onlineUsers = new Map(); // userId -> socketId

module.exports = function setupSocket(io) {
  // میدل‌ور احراز هویت سوکت
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.query?.token;
    if (!token) {
      return next(new Error('احراز هویت الزامی است.'));
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      socket.user = decoded;
      next();
    } catch (err) {
      next(new Error('نشست نامعتبر است.'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.user.id;
    onlineUsers.set(userId, socket.id);

    // به‌روزرسانی وضعیت آنلاین
    try {
      await query('UPDATE users SET is_online = true, last_seen = NOW() WHERE id = $1', [userId]);
    } catch (e) {}

    // پیوستن به اتاق‌های گفتگوهای کاربر
    try {
      const chats = await query('SELECT chat_id FROM chat_members WHERE user_id = $1', [userId]);
      chats.rows.forEach(c => socket.join(`chat:${c.chat_id}`));
    } catch (e) {}

    // اطلاع‌رسانی به دوستان
    socket.broadcast.emit('user:online', { user_id: userId, is_online: true });

    console.log(`✅ کاربر ${socket.user.username} متصل شد.`);

    // ارسال پیام
    socket.on('message:send', async (data, callback) => {
      try {
        const { chat_id, content, message_type, file_url, file_name, file_size, reply_to } = data || {};

        if (!chat_id || (!content && !file_url)) {
          return callback?.({ error: 'داده‌های پیام ناقص است.' });
        }

        // بررسی عضویت
        const member = await query(
          'SELECT 1 FROM chat_members WHERE chat_id = $1 AND user_id = $2',
          [chat_id, userId]
        );
        if (member.rows.length === 0) {
          return callback?.({ error: 'دسترسی غیرمجاز.' });
        }

        const result = await query(
          `INSERT INTO messages (chat_id, sender_id, content, message_type, file_url, file_name, file_size, reply_to)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           RETURNING *`,
          [chat_id, userId, content || '', message_type || 'text', file_url || null, file_name || null, file_size || null, reply_to || null]
        );

        const userInfo = await query(
          'SELECT username, display_name, avatar_url FROM users WHERE id = $1',
          [userId]
        );

        const message = {
          ...result.rows[0],
          sender_username: userInfo.rows[0].username,
          sender_name: userInfo.rows[0].display_name,
          sender_avatar: userInfo.rows[0].avatar_url,
          read_count: 0
        };

        // انتشار به همه اعضای گفتگو
        io.to(`chat:${chat_id}`).emit('message:new', message);
        callback?.({ success: true, message });
      } catch (err) {
        console.error('خطا در ارسال پیام:', err);
        callback?.({ error: 'خطا در ارسال پیام.' });
      }
    });

    // در حال تایپ
    socket.on('typing:start', (data) => {
      socket.to(`chat:${data.chat_id}`).emit('typing:update', {
        chat_id: data.chat_id,
        user_id: userId,
        display_name: socket.user.username,
        is_typing: true
      });
    });

    socket.on('typing:stop', (data) => {
      socket.to(`chat:${data.chat_id}`).emit('typing:update', {
        chat_id: data.chat_id,
        user_id: userId,
        display_name: socket.user.username,
        is_typing: false
      });
    });

    // خواندن پیام
    socket.on('message:read', async (data) => {
      try {
        const { message_id, chat_id } = data;
        await query(
          `INSERT INTO message_reads (message_id, user_id) VALUES ($1, $2)
           ON CONFLICT DO NOTHING`,
          [message_id, userId]
        );
        if (chat_id) {
          await query(
            'UPDATE chat_members SET last_read_message_id = $1 WHERE chat_id = $2 AND user_id = $3',
            [message_id, chat_id, userId]
          );
        }
        socket.to(`chat:${chat_id}`).emit('message:read:update', {
          message_id,
          user_id: userId,
          chat_id
        });
      } catch (e) {}
    });

    // ویرایش پیام
    socket.on('message:edit', async (data, callback) => {
      try {
        const { message_id, content } = data;
        const result = await query(
          `UPDATE messages SET content = $1, is_edited = true, updated_at = NOW()
           WHERE id = $2 AND sender_id = $3 RETURNING chat_id`,
          [content, message_id, userId]
        );
        if (result.rows.length === 0) {
          return callback?.({ error: 'شما مجاز به ویرایش این پیام نیستید.' });
        }
        io.to(`chat:${result.rows[0].chat_id}`).emit('message:edited', {
          id: message_id,
          content,
          is_edited: true
        });
        callback?.({ success: true });
      } catch (err) {
        callback?.({ error: 'خطا در ویرایش پیام.' });
      }
    });

    // حذف پیام
    socket.on('message:delete', async (data, callback) => {
      try {
        const { message_id } = data;
        const result = await query(
          `UPDATE messages SET is_deleted = true, content = NULL, file_url = NULL
           WHERE id = $1 AND sender_id = $2 RETURNING chat_id`,
          [message_id, userId]
        );
        if (result.rows.length === 0) {
          return callback?.({ error: 'شما مجاز به حذف این پیام نیستید.' });
        }
        io.to(`chat:${result.rows[0].chat_id}`).emit('message:deleted', { id: message_id });
        callback?.({ success: true });
      } catch (err) {
        callback?.({ error: 'خطا در حذف پیام.' });
      }
    });

    // قطع اتصال
    socket.on('disconnect', async () => {
      onlineUsers.delete(userId);
      try {
        await query('UPDATE users SET is_online = false, last_seen = NOW() WHERE id = $1', [userId]);
      } catch (e) {}
      socket.broadcast.emit('user:online', { user_id: userId, is_online: false });
      console.log(`❌ کاربر ${socket.user.username} قطع شد.`);
    });
  });
};
