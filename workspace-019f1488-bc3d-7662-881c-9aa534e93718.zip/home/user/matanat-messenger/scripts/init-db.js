require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

async function initDatabase() {
  const connectionString = process.env.DATABASE_URL;
  const pool = new Pool({
    connectionString,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
  });

  try {
    const schema = fs.readFileSync(path.join(__dirname, '../src/db/schema.sql'), 'utf8');
    console.log('📦 در حال ایجاد جداول دیتابیس...');
    await pool.query(schema);
    console.log('✅ جداول دیتابیس با موفقیت ایجاد شدند.');

    // Check if any user exists
    const result = await pool.query('SELECT COUNT(*) FROM users');
    if (parseInt(result.rows[0].count) === 0) {
      console.log('ℹ️  جدول کاربران خالی است. هیچ کاربر پیش‌فرضی ایجاد نمی‌شود.');
      console.log('   برای ثبت‌نام به صفحه /register بروید.');
    } else {
      console.log(`ℹ️  تعداد ${result.rows[0].count} کاربر در دیتابیس وجود دارد.`);
    }
  } catch (err) {
    console.error('❌ خطا در راه‌اندازی دیتابیس:', err.message);
    throw err;
  } finally {
    await pool.end();
  }
}

initDatabase()
  .then(() => process.exit(0))
  .catch(err => {
    console.error(err);
    process.exit(1);
  });
