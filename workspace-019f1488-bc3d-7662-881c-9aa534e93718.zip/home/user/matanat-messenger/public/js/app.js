// اپلیکیشن اصلی پیام‌رسان سهامداران متانت
(function() {
  'use strict';

  // ========== متغیرهای سراسری ==========
  const TOKEN = localStorage.getItem('matanat_token');
  let currentUser = null;
  let socket = null;
  let currentChatId = null;
  let chats = [];
  let messages = {};
  let typingUsers = {};
  let typingTimeout = null;
  let selectedMembersForGroup = [];
  let confirmCallback = null;

  if (!TOKEN) {
    window.location.href = '/login';
    return;
  }

  // ========== ابزارها ==========
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  function showToast(msg, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  function persianNumber(num) {
    const persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(num).replace(/[0-9]/g, d => persian[parseInt(d)]);
  }

  function formatTime(dateStr) {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = (now - date) / 1000;

    if (diff < 60) return 'همین الان';
    if (diff < 3600) return persianNumber(Math.floor(diff / 60)) + ' دقیقه پیش';
    if (diff < 86400) return persianNumber(Math.floor(diff / 3600)) + ' ساعت پیش';

    if (date.toDateString() === now.toDateString()) {
      return persianNumber(date.getHours()).padStart(2, '۰') + ':' + persianNumber(date.getMinutes()).padStart(2, '۰');
    }

    if (now - date < 86400 * 7) {
      const days = ['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه','شنبه'];
      return days[date.getDay()];
    }

    return persianNumber(date.getFullYear()) + '/' +
           persianNumber(date.getMonth() + 1).padStart(2, '۰') + '/' +
           persianNumber(date.getDate()).padStart(2, '۰');
  }

  function formatTimeShort(dateStr) {
    const date = new Date(dateStr);
    return persianNumber(date.getHours()).padStart(2, '۰') + ':' + persianNumber(date.getMinutes()).padStart(2, '۰');
  }

  function formatFileSize(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return persianNumber(bytes) + ' B';
    if (bytes < 1024 * 1024) return persianNumber(Math.round(bytes / 1024)) + ' KB';
    return persianNumber(Math.round(bytes / (1024 * 1024))) + ' MB';
  }

  function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) return parts[0][0] + parts[1][0];
    return name[0];
  }

  function getAvatarColor(name) {
    if (!name) return 0;
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return Math.abs(hash) % 8;
  }

  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function timeSince(dateStr) {
    const date = new Date(dateStr);
    const seconds = Math.floor((new Date() - date) / 1000);
    if (seconds < 60) return 'همین الان';
    if (seconds < 3600) return persianNumber(Math.floor(seconds / 60)) + ' دقیقه پیش';
    if (seconds < 86400) return persianNumber(Math.floor(seconds / 3600)) + ' ساعت پیش';
    return persianNumber(Math.floor(seconds / 86400)) + ' روز پیش';
  }

  // ========== API ==========
  async function api(url, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (TOKEN) headers['Authorization'] = `Bearer ${TOKEN}`;

    const res = await fetch(url, { ...options, headers });
    const data = await res.json().catch(() => ({}));

    if (res.status === 401) {
      localStorage.removeItem('matanat_token');
      localStorage.removeItem('matanat_user');
      window.location.href = '/login';
      return null;
    }

    return { ok: res.ok, status: res.status, data };
  }

  // ========== احراز هویت ==========
  async function loadCurrentUser() {
    const res = await api('/api/auth/me');
    if (res && res.ok) {
      currentUser = res.data.user;
      localStorage.setItem('matanat_user', JSON.stringify(currentUser));
      updateSettingsUI();
    }
  }

  // ========== بارگذاری گفتگوها ==========
  async function loadChats() {
    const res = await api('/api/chats');
    if (res && res.ok) {
      chats = res.data.chats;
      renderChats();
    }
  }

  function renderChats() {
    const list = $('#chatsList');

    if (chats.length === 0) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">💬</div>
          <h3>گفتگویی ندارید</h3>
          <p>برای شروع، روی دکمه ✏️ بزنید تا با دوستان خود گفتگو کنید یا یک گروه جدید بسازید.</p>
        </div>
      `;
      return;
    }

    list.innerHTML = chats.map(chat => {
      const isOnline = chat.other_user?.is_online;
      const lastMsg = chat.last_message || 'گفتگوی خالی';
      const lastType = chat.last_message_type;
      const lastSender = chat.last_sender_name;
      const isMine = lastSender && lastSender === currentUser?.display_name;

      let previewHtml = '';
      if (!lastMsg) {
        previewHtml = '<span class="chat-last-message">گفتگوی خالی</span>';
      } else if (lastType === 'image') {
        previewHtml = `<span class="chat-last-message">${isMine ? 'شما: ' : ''}📷 تصویر</span>`;
      } else if (lastType === 'file') {
        previewHtml = `<span class="chat-last-message">${isMine ? 'شما: ' : ''}📎 فایل</span>`;
      } else {
        const truncated = lastMsg.length > 40 ? lastMsg.substring(0, 40) + '...' : lastMsg;
        previewHtml = `<span class="chat-last-message">${isMine ? 'شما: ' : ''}${escapeHtml(truncated)}</span>`;
      }

      return `
        <div class="chat-item" data-chat-id="${chat.id}">
          <div class="chat-avatar" style="${chat.avatar_url ? `background-image: url('${chat.avatar_url}')` : ''}">
            ${!chat.avatar_url ? getInitials(chat.name || '?') : ''}
            ${isOnline ? '<div class="online-dot"></div>' : ''}
          </div>
          <div class="chat-info">
            <div class="chat-info-header">
              <div class="chat-name">${escapeHtml(chat.name || 'بدون نام')}</div>
              <div class="chat-time">${chat.last_message_time ? formatTime(chat.last_message_time) : ''}</div>
            </div>
            <div class="chat-preview">
              ${previewHtml}
              ${chat.unread_count > 0 ? `<div class="unread-badge">${persianNumber(chat.unread_count)}</div>` : ''}
            </div>
          </div>
        </div>
      `;
    }).join('');

    $$('.chat-item').forEach(item => {
      item.addEventListener('click', () => {
        const chatId = parseInt(item.dataset.chatId);
        openChat(chatId);
        if (window.innerWidth <= 768) {
          $('#sidebar').classList.add('hidden');
        }
      });
    });
  }

  // ========== بارگذاری پیام‌ها ==========
  async function loadMessages(chatId) {
    const res = await api(`/api/messages/chat/${chatId}?limit=50`);
    if (res && res.ok) {
      messages[chatId] = res.data.messages;
      renderMessages();
    }
  }

  function renderMessages() {
    if (!currentChatId) return;
    const list = $('#messagesList');
    const msgs = messages[currentChatId] || [];

    if (msgs.length === 0) {
      list.innerHTML = `
        <div class="empty-state" style="padding: 60px 20px;">
          <div class="empty-state-icon">📭</div>
          <h3>پیامی وجود ندارد</h3>
          <p>اولین پیام را شما بفرستید!</p>
        </div>
      `;
      return;
    }

    list.innerHTML = msgs.map((msg, idx) => renderMessage(msg, idx, msgs)).join('');
    scrollToBottom();

    // پس از رندر، خوانده شدن پیام‌ها را علامت بزن
    msgs.forEach(msg => {
      if (msg.sender_id !== currentUser.id) {
        socket?.emit('message:read', { message_id: msg.id, chat_id: currentChatId });
      }
    });
  }

  function renderMessage(msg, idx, allMsgs) {
    const isMine = msg.sender_id === currentUser.id;
    const prevMsg = idx > 0 ? allMsgs[idx - 1] : null;
    const chat = chats.find(c => c.id === currentChatId);
    const isGroupChat = chat && (chat.type === 'group' || chat.type === 'channel');
    const showSenderInGroup = !isMine && isGroupChat && (!prevMsg || prevMsg.sender_id !== msg.sender_id);

    let contentHtml = '';
    if (msg.is_deleted) {
      contentHtml = '<span class="message-deleted">این پیام حذف شد</span>';
    } else {
      if (msg.reply_to && messages[currentChatId]) {
        const replyMsg = messages[currentChatId].find(m => m.id === msg.reply_to);
        if (replyMsg) {
          contentHtml += `
            <div class="message-reply">
              <div class="message-reply-name">${escapeHtml(replyMsg.sender_name || 'کاربر')}</div>
              <div class="message-reply-text">${escapeHtml(replyMsg.is_deleted ? 'پیام حذف شده' : (replyMsg.content || 'پیام'))}</div>
            </div>
          `;
        }
      }

      if (msg.message_type === 'image' && msg.file_url) {
        contentHtml += `<img src="${msg.file_url}" class="message-image" alt="تصویر" onclick="window.open('${msg.file_url}','_blank')">`;
        if (msg.content) {
          contentHtml += `<div class="message-content">${escapeHtml(msg.content)}</div>`;
        }
      } else if (msg.message_type === 'file' && msg.file_url) {
        contentHtml += `
          <a href="${msg.file_url}" target="_blank" class="message-file" style="text-decoration:none; color:inherit;">
            <div class="message-file-icon">📎</div>
            <div class="message-file-info">
              <div class="message-file-name">${escapeHtml(msg.file_name || 'فایل')}</div>
              <div class="message-file-size">${formatFileSize(msg.file_size)}</div>
            </div>
          </a>
        `;
        if (msg.content) {
          contentHtml += `<div class="message-content">${escapeHtml(msg.content)}</div>`;
        }
      } else {
        contentHtml += `<div class="message-content">${escapeHtml(msg.content || '')}</div>`;
      }
    }

    return `
      <div class="message-group">
        ${showSenderInGroup ? `<div class="message-sender-name">${escapeHtml(msg.sender_name || 'کاربر')}</div>` : ''}
        <div class="message-bubble ${isMine ? 'message-out' : 'message-in'}" data-message-id="${msg.id}">
          ${isMine && !msg.is_deleted ? `
            <div class="message-actions">
              <button class="action-btn" onclick="app.replyToMessage(${msg.id})" title="پاسخ">↩️</button>
              <button class="action-btn" onclick="app.editMessage(${msg.id})" title="ویرایش">✏️</button>
              <button class="action-btn" onclick="app.deleteMessage(${msg.id})" title="حذف">🗑️</button>
            </div>
          ` : (!isMine && !msg.is_deleted ? `
            <div class="message-actions">
              <button class="action-btn" onclick="app.replyToMessage(${msg.id})" title="پاسخ">↩️</button>
            </div>
          ` : '')}
          ${contentHtml}
          <div class="message-meta">
            ${msg.is_edited && !msg.is_deleted ? '<span class="message-edited">ویرایش شد</span>' : ''}
            <span>${formatTimeShort(msg.created_at)}</span>
            ${isMine && !msg.is_deleted ? `<span class="message-check ${msg.read_count > 0 ? 'read' : ''}">${msg.read_count > 0 ? '✓✓' : '✓'}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }

  function scrollToBottom() {
    const area = $('#messagesArea');
    setTimeout(() => {
      area.scrollTop = area.scrollHeight;
    }, 50);
  }

  // ========== باز کردن گفتگو ==========
  async function openChat(chatId) {
    currentChatId = chatId;

    // به‌روزرسانی UI
    $$('.chat-item').forEach(item => item.classList.remove('active'));
    const item = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
    if (item) item.classList.add('active');

    $('#welcomeScreen').style.display = 'none';
    $('#activeChat').style.display = 'flex';

    const chat = chats.find(c => c.id === chatId);
    if (!chat) return;

    // هدر
    const avatar = $('#chatHeaderAvatar');
    if (chat.avatar_url) {
      avatar.style.backgroundImage = `url('${chat.avatar_url}')`;
      avatar.textContent = '';
    } else {
      avatar.style.backgroundImage = '';
      avatar.textContent = getInitials(chat.name || '?');
      avatar.className = `chat-avatar avatar-color-${getAvatarColor(chat.name || '')}`;
    }

    $('#chatHeaderName').textContent = chat.name || 'بدون نام';

    const statusEl = $('#chatHeaderStatus');
    if (chat.type === 'private') {
      if (chat.other_user?.is_online) {
        statusEl.textContent = 'آنلاین';
        statusEl.classList.add('online');
      } else if (chat.other_user?.last_seen) {
        statusEl.classList.remove('online');
        statusEl.textContent = 'آخرین بازدید ' + timeSince(chat.other_user.last_seen);
      } else {
        statusEl.classList.remove('online');
        statusEl.textContent = '';
      }
    } else if (chat.type === 'group') {
      statusEl.classList.remove('online');
      statusEl.textContent = persianNumber(chat.member_count || 0) + ' عضو';
    } else if (chat.type === 'channel') {
      statusEl.classList.remove('online');
      statusEl.textContent = 'کانال';
    }

    // بارگذاری پیام‌ها
    await loadMessages(chatId);

    // سوکت قبلاً در connection به اتاق‌ها پیوسته است
  }

  // ========== ارسال پیام ==========
  function sendMessage() {
    const input = $('#messageInput');
    const content = input.value.trim();
    const replyPreview = $('#replyPreview');
    const replyToId = replyPreview.dataset.replyTo || null;

    if (!content || !currentChatId) return;

    const chat = chats.find(c => c.id === currentChatId);
    const isChannel = chat && chat.type === 'channel';

    if (isChannel && chat.my_role !== 'admin' && currentUser.id !== chat.created_by) {
      showToast('فقط مدیران کانال می‌توانند پیام ارسال کنند.', 'error');
      return;
    }

    socket.emit('message:send', {
      chat_id: currentChatId,
      content,
      message_type: 'text',
      reply_to: replyToId
    });

    input.value = '';
    input.style.height = 'auto';
    updateSendButton();
    cancelReply();
  }

  function updateSendButton() {
    const input = $('#messageInput');
    const sendBtn = $('#sendBtn');
    sendBtn.disabled = !input.value.trim();
  }

  // ========== آپلود فایل ==========
  async function uploadFile(file, isImage = false) {
    if (!file || !currentChatId) return;

    if (file.size > 50 * 1024 * 1024) {
      showToast('حجم فایل نباید بیشتر از ۵۰ مگابایت باشد.', 'error');
      return;
    }

    showToast('در حال آپلود فایل...', 'info');

    const formData = new FormData();
    formData.append(isImage ? 'image' : 'file', file);

    try {
      const res = await fetch(`/api/upload/${isImage ? 'image' : 'file'}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${TOKEN}` },
        body: formData
      });
      const data = await res.json();

      if (res.ok && data.success) {
        socket.emit('message:send', {
          chat_id: currentChatId,
          content: '',
          message_type: isImage ? 'image' : 'file',
          file_url: data.file_url,
          file_name: data.file_name,
          file_size: data.file_size
        });
      } else {
        showToast(data.error || 'خطا در آپلود فایل.', 'error');
      }
    } catch (err) {
      showToast('خطا در آپلود فایل.', 'error');
    }
  }

  // ========== پاسخ به پیام ==========
  window.app = window.app || {};
  window.app.replyToMessage = function(messageId) {
    const msg = (messages[currentChatId] || []).find(m => m.id === messageId);
    if (!msg) return;

    const preview = $('#replyPreview');
    preview.style.display = 'flex';
    preview.dataset.replyTo = messageId;

    $('#replyName').textContent = 'پاسخ به ' + (msg.sender_name || 'کاربر');
    $('#replyText').textContent = msg.is_deleted ? 'پیام حذف شده' : (msg.content || '📎 فایل');

    $('#messageInput').focus();
  };

  function cancelReply() {
    const preview = $('#replyPreview');
    preview.style.display = 'none';
    preview.dataset.replyTo = '';
  }

  // ========== ویرایش پیام ==========
  window.app.editMessage = function(messageId) {
    const msg = (messages[currentChatId] || []).find(m => m.id === messageId);
    if (!msg) return;

    const input = $('#messageInput');
    input.value = msg.content || '';
    input.focus();
    updateSendButton();

    // تنظیم برای ویرایش
    input.dataset.editingId = messageId;

    const sendBtn = $('#sendBtn');
    sendBtn.textContent = '✓';
    sendBtn.onclick = function() {
      if (input.dataset.editingId) {
        const newContent = input.value.trim();
        if (!newContent) return;
        socket.emit('message:edit', { message_id: parseInt(input.dataset.editingId), content: newContent });
        input.value = '';
        delete input.dataset.editingId;
        sendBtn.textContent = '➤';
        sendBtn.onclick = sendMessage;
        updateSendButton();
      }
    };
  };

  // ========== حذف پیام ==========
  window.app.deleteMessage = function(messageId) {
    showConfirm('حذف پیام', 'آیا از حذف این پیام مطمئن هستید؟', () => {
      socket.emit('message:delete', { message_id: messageId });
    });
  };

  // ========== تأیید ==========
  function showConfirm(title, message, callback) {
    $('#confirmTitle').textContent = title;
    $('#confirmMessage').textContent = message;
    $('#confirmModal').classList.add('show');
    confirmCallback = callback;
  }

  $('#confirmOk')?.addEventListener('click', () => {
    $('#confirmModal').classList.remove('show');
    if (confirmCallback) confirmCallback();
    confirmCallback = null;
  });

  $('#confirmCancel')?.addEventListener('click', () => {
    $('#confirmModal').classList.remove('show');
    confirmCallback = null;
  });

  // ========== سوکت ==========
  function connectSocket() {
    socket = io({ auth: { token: TOKEN } });

    socket.on('connect', () => {
      console.log('✅ به سرور متصل شدید');
    });

    socket.on('connect_error', (err) => {
      console.error('خطای اتصال:', err.message);
      if (err.message.includes('نشست') || err.message.includes('احراز')) {
        localStorage.removeItem('matanat_token');
        window.location.href = '/login';
      }
    });

    socket.on('message:new', (message) => {
      const chatId = message.chat_id;
      if (!messages[chatId]) messages[chatId] = [];
      messages[chatId].push(message);

      if (chatId === currentChatId) {
        renderMessages();
        socket.emit('message:read', { message_id: message.id, chat_id: chatId });
      } else {
        // نمایش اعلان
        const chat = chats.find(c => c.id === chatId);
        showToast(`پیام جدید از ${message.sender_name || chat?.name || 'کاربر'}`, 'info');
      }
      loadChats();
    });

    socket.on('message:edited', (data) => {
      Object.values(messages).forEach(msgs => {
        const m = msgs.find(x => x.id === data.id);
        if (m) {
          m.content = data.content;
          m.is_edited = true;
        }
      });
      if (currentChatId) renderMessages();
    });

    socket.on('message:deleted', (data) => {
      Object.values(messages).forEach(msgs => {
        const m = msgs.find(x => x.id === data.id);
        if (m) {
          m.is_deleted = true;
          m.content = null;
          m.file_url = null;
        }
      });
      if (currentChatId) renderMessages();
    });

    socket.on('message:read:update', (data) => {
      Object.values(messages).forEach(msgs => {
        const m = msgs.find(x => x.id === data.message_id);
        if (m) m.read_count = (m.read_count || 0) + 1;
      });
      if (currentChatId) renderMessages();
    });

    socket.on('typing:update', (data) => {
      if (data.chat_id !== currentChatId) return;

      if (!typingUsers[data.chat_id]) typingUsers[data.chat_id] = {};
      if (data.is_typing) {
        typingUsers[data.chat_id][data.user_id] = data.display_name;
      } else {
        delete typingUsers[data.chat_id][data.user_id];
      }
      renderTypingIndicator();
    });

    socket.on('user:online', (data) => {
      // به‌روزرسانی وضعیت آنلاین
      const userId = data.user_id;
      chats.forEach(chat => {
        if (chat.other_user && chat.other_user.id === userId) {
          chat.other_user.is_online = data.is_online;
        }
      });
      renderChats();
      if (currentChatId) {
        const chat = chats.find(c => c.id === currentChatId);
        if (chat && chat.other_user) {
          const statusEl = $('#chatHeaderStatus');
          if (data.is_online) {
            statusEl.textContent = 'آنلاین';
            statusEl.classList.add('online');
          } else if (chat.other_user.last_seen) {
            statusEl.classList.remove('online');
            statusEl.textContent = 'آخرین بازدید ' + timeSince(chat.other_user.last_seen);
          }
        }
      }
    });
  }

  function renderTypingIndicator() {
    const list = $('#messagesList');
    const existing = $('#typingIndicator');
    if (existing) existing.remove();

    if (!currentChatId) return;
    const typing = typingUsers[currentChatId];
    if (!typing || Object.keys(typing).length === 0) return;

    const names = Object.values(typing);
    let text = '';
    if (names.length === 1) text = names[0] + ' در حال نوشتن';
    else if (names.length === 2) text = names[0] + ' و ' + names[1] + ' در حال نوشتن';
    else text = persianNumber(names.length) + ' نفر در حال نوشتن';

    const html = `
      <div id="typingIndicator" class="typing-indicator">
        <span>${escapeHtml(text)}</span>
        <div class="typing-dots">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    `;
    list.insertAdjacentHTML('beforeend', html);
    scrollToBottom();
  }

  // ========== مودال‌ها ==========
  function showModal(id) {
    $('#' + id).classList.add('show');
  }
  function hideModal(id) {
    $('#' + id).classList.remove('show');
  }

  $$('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => hideModal(btn.dataset.closeModal));
  });

  $$('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.classList.remove('show');
    });
  });

  // ========== گفتگوی جدید ==========
  $('#newChatBtn').addEventListener('click', () => {
    showModal('newChatModal');
    $('#userSearchInput').focus();
  });

  let searchTimeout;
  $('#userSearchInput').addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    const q = e.target.value.trim();
    if (q.length < 2) {
      $('#userSearchResults').innerHTML = '';
      return;
    }
    searchTimeout = setTimeout(async () => {
      const res = await api(`/api/users/search?q=${encodeURIComponent(q)}`);
      if (res && res.ok) {
        const results = $('#userSearchResults');
        if (res.data.users.length === 0) {
          results.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;">کاربری یافت نشد.</p>';
          return;
        }
        results.innerHTML = res.data.users.map(u => `
          <div class="member-item" data-user-id="${u.id}">
            <div class="member-avatar" style="${u.avatar_url ? `background-image:url('${u.avatar_url}')` : ''}">
              ${!u.avatar_url ? getInitials(u.display_name) : ''}
            </div>
            <div class="member-info">
              <div class="member-name">${escapeHtml(u.display_name)}</div>
              <div class="member-status ${u.is_online ? 'online' : ''}">${u.is_online ? 'آنلاین' : '@' + escapeHtml(u.username)}</div>
            </div>
            <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;">شروع گفتگو</button>
          </div>
        `).join('');

        $$('#userSearchResults .member-item').forEach(item => {
          item.addEventListener('click', async () => {
            const userId = parseInt(item.dataset.userId);
            const res = await api('/api/chats/private', {
              method: 'POST',
              body: JSON.stringify({ user_id: userId })
            });
            if (res && res.ok) {
              hideModal('newChatModal');
              await loadChats();
              openChat(res.data.chat_id);
              $('#userSearchInput').value = '';
              $('#userSearchResults').innerHTML = '';
            }
          });
        });
      }
    }, 300);
  });

  // ========== ساخت گروه ==========
  $('#createGroupBtn').addEventListener('click', () => {
    hideModal('newChatModal');
    showModal('createGroupModal');
    selectedMembersForGroup = [];
    updateSelectedMembers();
  });

  $('#groupMemberSearch').addEventListener('input', (e) => {
    const q = e.target.value.trim();
    if (q.length < 2) {
      $('#groupMemberSearchResults').innerHTML = '';
      return;
    }
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(async () => {
      const res = await api(`/api/users/search?q=${encodeURIComponent(q)}`);
      if (res && res.ok) {
        const results = $('#groupMemberSearchResults');
        results.innerHTML = res.data.users.map(u => {
          const isSelected = selectedMembersForGroup.includes(u.id);
          return `
            <div class="member-item" data-user-id="${u.id}">
              <div class="member-avatar" style="${u.avatar_url ? `background-image:url('${u.avatar_url}')` : ''}">
                ${!u.avatar_url ? getInitials(u.display_name) : ''}
              </div>
              <div class="member-info">
                <div class="member-name">${escapeHtml(u.display_name)}</div>
                <div class="member-status">@${escapeHtml(u.username)}</div>
              </div>
              <button class="btn ${isSelected ? 'btn-primary' : 'btn-secondary'}" style="padding: 6px 12px; font-size: 12px;">
                ${isSelected ? '✓ انتخاب شد' : 'افزودن'}
              </button>
            </div>
          `;
        }).join('');

        $$('#groupMemberSearchResults .member-item').forEach(item => {
          item.addEventListener('click', () => {
            const userId = parseInt(item.dataset.userId);
            if (selectedMembersForGroup.includes(userId)) {
              selectedMembersForGroup = selectedMembersForGroup.filter(id => id !== userId);
            } else {
              selectedMembersForGroup.push(userId);
            }
            updateSelectedMembers();
            // رندر مجدد
            $('#groupMemberSearch').dispatchEvent(new Event('input'));
          });
        });
      }
    }, 300);
  });

  function updateSelectedMembers() {
    const container = $('#selectedMembers');
    if (selectedMembersForGroup.length === 0) {
      container.innerHTML = '<p style="color: var(--text-muted); font-size: 12px;">هنوز کسی انتخاب نشده است.</p>';
      return;
    }
    container.innerHTML = selectedMembersForGroup.length + ' عضو انتخاب شده';
  }

  $('#submitGroupBtn').addEventListener('click', async () => {
    const name = $('#groupNameInput').value.trim();
    const description = $('#groupDescInput').value.trim();

    if (!name) {
      showToast('لطفاً نام گروه را وارد کنید.', 'error');
      return;
    }
    if (selectedMembersForGroup.length === 0) {
      showToast('حداقل یک عضو انتخاب کنید.', 'error');
      return;
    }

    const res = await api('/api/chats/group', {
      method: 'POST',
      body: JSON.stringify({ name, description, members: selectedMembersForGroup })
    });

    if (res && res.ok) {
      hideModal('createGroupModal');
      $('#groupNameInput').value = '';
      $('#groupDescInput').value = '';
      selectedMembersForGroup = [];
      await loadChats();
      openChat(res.data.chat_id);
      showToast('گروه با موفقیت ساخته شد.', 'success');
    } else {
      showToast(res?.data?.error || 'خطا در ساخت گروه.', 'error');
    }
  });

  // ========== ساخت کانال ==========
  $('#createChannelBtn').addEventListener('click', () => {
    hideModal('newChatModal');
    showModal('createChannelModal');
  });

  $('#submitChannelBtn').addEventListener('click', async () => {
    const name = $('#channelNameInput').value.trim();
    const description = $('#channelDescInput').value.trim();
    const is_public = $('#channelPublicCheck').checked;

    if (!name) {
      showToast('لطفاً نام کانال را وارد کنید.', 'error');
      return;
    }

    const res = await api('/api/chats/channel', {
      method: 'POST',
      body: JSON.stringify({ name, description, is_public })
    });

    if (res && res.ok) {
      hideModal('createChannelModal');
      $('#channelNameInput').value = '';
      $('#channelDescInput').value = '';
      await loadChats();
      openChat(res.data.chat_id);
      showToast('کانال با موفقیت ساخته شد.', 'success');
    } else {
      showToast(res?.data?.error || 'خطا در ساخت کانال.', 'error');
    }
  });

  // ========== اطلاعات گفتگو ==========
  $('#chatHeaderInfo').addEventListener('click', async () => {
    if (!currentChatId) return;
    const res = await api(`/api/chats/${currentChatId}`);
    if (res && res.ok) {
      const chat = res.data.chat;
      const body = $('#chatInfoBody');
      let html = `
        <div class="profile-header">
          <div class="profile-avatar" style="${chat.avatar_url ? `background-image:url('${chat.avatar_url}')` : ''}">
            ${!chat.avatar_url ? getInitials(chat.name || '?') : ''}
          </div>
          <div class="profile-name">${escapeHtml(chat.name || 'بدون نام')}</div>
          ${chat.type === 'private' && chat.members[0] ? `
            <div class="profile-username">@${escapeHtml(chat.members[0].username || '')}</div>
            <div class="profile-bio">${escapeHtml(chat.members[0].is_online ? 'آنلاین' : 'آفلاین')}</div>
          ` : ''}
          ${chat.description ? `<div class="profile-bio">${escapeHtml(chat.description)}</div>` : ''}
        </div>
        <div class="settings-title">${persianNumber(chat.members.length)} عضو</div>
        <div class="members-list">
          ${chat.members.map(m => `
            <div class="member-item">
              <div class="member-avatar" style="${m.avatar_url ? `background-image:url('${m.avatar_url}')` : ''}">
                ${!m.avatar_url ? getInitials(m.display_name) : ''}
              </div>
              <div class="member-info">
                <div class="member-name">${escapeHtml(m.display_name)} ${m.role === 'admin' ? '⭐' : ''}</div>
                <div class="member-status ${m.is_online ? 'online' : ''}">${m.is_online ? 'آنلاین' : timeSince(m.last_seen || new Date())}</div>
              </div>
            </div>
          `).join('')}
        </div>
      `;
      body.innerHTML = html;
      showModal('chatInfoModal');
    }
  });

  // ========== منوی گفتگو ==========
  $('#chatMenuBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    const dropdown = $('#chatDropdown');
    const rect = e.target.getBoundingClientRect();
    dropdown.style.top = (rect.bottom + 4) + 'px';
    dropdown.style.left = (window.innerWidth - rect.right) + 'px';
    dropdown.classList.toggle('show');
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('#chatDropdown') && !e.target.closest('#chatMenuBtn')) {
      $('#chatDropdown').classList.remove('show');
    }
  });

  $$('#chatDropdown .dropdown-item').forEach(item => {
    item.addEventListener('click', async () => {
      const action = item.dataset.action;
      $('#chatDropdown').classList.remove('show');

      if (action === 'info') {
        $('#chatHeaderInfo').click();
      } else if (action === 'clear') {
        showConfirm('پاک کردن گفتگو', 'آیا از پاک کردن همه پیام‌های این گفتگو مطمئن هستید؟ این عملیات غیرقابل بازگشت است.', () => {
          // TODO: پیاده‌سازی حذف همه پیام‌ها
          showToast('این قابلیت به زودی اضافه خواهد شد.', 'info');
        });
      } else if (action === 'search') {
        showModal('searchInChatModal');
        $('#searchInChatInput').focus();
      } else if (action === 'mute') {
        showToast('گفتگو بی‌صدا شد.', 'success');
      } else if (action === 'leave' && currentChatId) {
        showConfirm('خروج از گفتگو', 'آیا از خروج از این گفتگو مطمئن هستید؟', async () => {
          await api(`/api/chats/${currentChatId}`, { method: 'DELETE' });
          currentChatId = null;
          $('#activeChat').style.display = 'none';
          $('#welcomeScreen').style.display = 'flex';
          await loadChats();
          if (window.innerWidth <= 768) $('#sidebar').classList.remove('hidden');
          showToast('از گفتگو خارج شدید.', 'success');
        });
      }
    });
  });

  // ========== جستجو در پیام‌ها ==========
  $('#searchInChatInput').addEventListener('input', (e) => {
    const q = e.target.value.trim();
    if (q.length < 2 || !currentChatId) {
      $('#searchInChatResults').innerHTML = '';
      return;
    }
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(async () => {
      const res = await api(`/api/messages/search/${currentChatId}?q=${encodeURIComponent(q)}`);
      if (res && res.ok) {
        const results = $('#searchInChatResults');
        if (res.data.messages.length === 0) {
          results.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;">نتیجه‌ای یافت نشد.</p>';
          return;
        }
        results.innerHTML = res.data.messages.map(m => `
          <div class="member-item">
            <div class="member-avatar" style="background: var(--primary);">${getInitials(m.sender_name || '?')}</div>
            <div class="member-info">
              <div class="member-name">${escapeHtml(m.sender_name || 'کاربر')}</div>
              <div class="member-status">${escapeHtml(m.content || 'پیام')}</div>
              <div class="member-status" style="font-size: 11px;">${formatTime(m.created_at)}</div>
            </div>
          </div>
        `).join('');
      }
    }, 300);
  });

  // ========== تنظیمات ==========
  $('#settingsBtn').addEventListener('click', () => {
    updateSettingsUI();
    showModal('settingsModal');
  });

  function updateSettingsUI() {
    if (!currentUser) return;
    const avatar = $('#settingsAvatar');
    if (currentUser.avatar_url) {
      avatar.style.backgroundImage = `url('${currentUser.avatar_url}')`;
      avatar.textContent = '';
    } else {
      avatar.style.backgroundImage = '';
      avatar.textContent = getInitials(currentUser.display_name);
      avatar.className = `profile-avatar avatar-color-${getAvatarColor(currentUser.display_name)}`;
    }
    $('#settingsName').textContent = currentUser.display_name;
    $('#settingsUsername').textContent = '@' + currentUser.username + ' • ' + currentUser.phone;
    $('#settingsBio').textContent = currentUser.bio || 'بدون بیو';
  }

  $('#editProfileBtn').addEventListener('click', () => {
    $('#editDisplayName').value = currentUser.display_name;
    $('#editBio').value = currentUser.bio || '';
    showModal('editProfileModal');
  });

  $('#saveProfileBtn').addEventListener('click', async () => {
    const display_name = $('#editDisplayName').value.trim();
    const bio = $('#editBio').value.trim();

    if (!display_name) {
      showToast('نام نمایشی نمی‌تواند خالی باشد.', 'error');
      return;
    }

    const res = await api('/api/users/me', {
      method: 'PUT',
      body: JSON.stringify({ display_name, bio })
    });

    if (res && res.ok) {
      currentUser = { ...currentUser, ...res.data.user };
      localStorage.setItem('matanat_user', JSON.stringify(currentUser));
      hideModal('editProfileModal');
      updateSettingsUI();
      loadChats();
      showToast('پروفایل به‌روزرسانی شد.', 'success');
    } else {
      showToast(res?.data?.error || 'خطا در به‌روزرسانی.', 'error');
    }
  });

  $('#logoutBtn').addEventListener('click', () => {
    showConfirm('خروج از حساب', 'آیا از خروج مطمئن هستید؟', async () => {
      await api('/api/auth/logout', { method: 'POST' });
      localStorage.removeItem('matanat_token');
      localStorage.removeItem('matanat_user');
      window.location.href = '/login';
    });
  });

  // ========== جستجوی گفتگوها ==========
  $('#searchInput').addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    $$('.chat-item').forEach(item => {
      const name = item.querySelector('.chat-name').textContent.toLowerCase();
      item.style.display = name.includes(q) ? 'flex' : 'none';
    });
  });

  // ========== ارسال پیام با Enter ==========
  $('#messageInput').addEventListener('input', () => {
    const input = $('#messageInput');
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    updateSendButton();

    if (currentChatId && !input.dataset.editingId) {
      socket.emit('typing:start', { chat_id: currentChatId });
      clearTimeout(typingTimeout);
      typingTimeout = setTimeout(() => {
        socket.emit('typing:stop', { chat_id: currentChatId });
      }, 3000);
    }
  });

  $('#messageInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  $('#sendBtn').addEventListener('click', sendMessage);

  $('#cancelReplyBtn').addEventListener('click', cancelReply);

  // ========== پیوست فایل ==========
  $('#attachBtn').addEventListener('click', () => {
    $('#fileInput').click();
  });

  $('#fileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const isImage = file.type.startsWith('image/');
    uploadFile(file, isImage);
    e.target.value = '';
  });

  // ========== بازگشت در موبایل ==========
  $('#backBtn').addEventListener('click', () => {
    if (window.innerWidth <= 768) {
      $('#sidebar').classList.remove('hidden');
      $('#chatPanel').classList.add('hidden');
      currentChatId = null;
    }
  });

  // ========== دکمه شکلک (ساده) ==========
  $('#emojiBtn').addEventListener('click', () => {
    const input = $('#messageInput');
    const emojis = ['😀','😂','😍','🥰','😎','🤔','😊','😢','😡','👍','👎','👏','🙏','🔥','❤️','💔','⭐','🎉','✅','❌'];
    input.value += emojis[Math.floor(Math.random() * emojis.length)];
    updateSendButton();
    input.focus();
  });

  // ========== شروع ==========
  async function init() {
    try {
      currentUser = JSON.parse(localStorage.getItem('matanat_user') || 'null');
      await loadCurrentUser();
      await loadChats();
      connectSocket();
    } catch (err) {
      console.error('خطا در راه‌اندازی:', err);
      window.location.href = '/login';
    }
  }

  init();
})();
