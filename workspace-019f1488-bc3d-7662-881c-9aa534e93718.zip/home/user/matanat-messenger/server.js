require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const { Server } = require('socket.io');

const { testConnection } = require('./src/db/connection');
const authRoutes = require('./src/routes/auth');
const userRoutes = require('./src/routes/users');
const chatRoutes = require('./src/routes/chats');
const messageRoutes = require('./src/routes/messages');
const uploadRoutes = require('./src/routes/upload');
const setupSocket = require('./src/sockets/socketHandler');

const app = express();
const server = http.createServer(app);

// Middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(compression());
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  message: { error: 'تعداد درخواست‌ها زیاد است. لطفاً کمی صبر کنید.' }
});
app.use('/api/', limiter);

// View engine
app.set('view engine', 'html');
app.engine('html', (filePath, options, callback) => {
  const fs = require('fs');
  fs.readFile(filePath, (err, content) => {
    if (err) return callback(err);
    callback(null, content.toString());
  });
});

// Routes
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'سهامداران متانت',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/upload', uploadRoutes);

// Page routes
app.get('/', (req, res) => res.render(path.join(__dirname, 'public/index.html')));
app.get('/login', (req, res) => res.render(path.join(__dirname, 'public/login.html')));
app.get('/register', (req, res) => res.render(path.join(__dirname, 'public/register.html')));
app.get('/chat', (req, res) => res.render(path.join(__dirname, 'public/chat.html')));
app.get('/settings', (req, res) => res.render(path.join(__dirname, 'public/settings.html')));

// Socket.io
const io = new Server(server, {
  cors: {
    origin: true,
    credentials: true
  },
  maxHttpBufferSize: 50 * 1024 * 1024
});

setupSocket(io);

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'خطای سرور. لطفاً دوباره تلاش کنید.'
  });
});

// 404
app.use((req, res) => {
  res.status(404).json({ error: 'صفحه یا منبع مورد نظر یافت نشد.' });
});

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await testConnection();
    server.listen(PORT, '0.0.0.0', () => {
      console.log('╔════════════════════════════════════════╗');
      console.log('║   پیام‌رسان سهامداران متانت   ║');
      console.log('╚════════════════════════════════════════╝');
      console.log(`🚀 سرور روی پورت ${PORT} در حال اجراست`);
      console.log(`📱 آدرس: http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('❌ خطا در راه‌اندازی سرور:', err.message);
    process.exit(1);
  }
}

start();

process.on('SIGTERM', () => {
  console.log('دریافت سیگنال SIGTERM. در حال خاموش کردن...');
  server.close(() => process.exit(0));
});
